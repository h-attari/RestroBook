import json
r11={}
r11['starter']={}
r11['starter']['Soup']={'Tomato Soup':135,'Veg Manchow Soup':135,'Veg Hot and Sour Soup':130,'Veg Sweet Corn Soup':135,'Lemon Corriander Soup':130,'Cream of Mushroom Soup':149}
r11['starter']['Indian']={'Veg Pakora':200,'Onion Pakora':200,'Aloo Pakora':200,'Paneer Pakora':255,'Hara Bhara Kebab':225,'Dahi ka Kebab':155}
r11['starter']['Chinese']={'Chilli Paneer':265,'Paneer 65':265,'Veg Manchurian':225,'Chilli Potato':210,'Veg Kothe':225}
r11['starter']['Thai']={'Boiled Veg':225,'Stir Veg in Thai Curry':225,'Stir Fried Veg in Thai Curry with Rice':300}
r11['starter']['Continental']={"Herb's Fusili Pasta":225,'Fusilli Arabiatta Pasta':245,'Napolitan Fusilli Pasta':300,'Paneer Satey':300,'Baked Veg':300}
r11['main course']={}
r11['main course']['Veg']={'Food Packet':195,'Shahi Paneer':310,'Paneer Pasanda':320,'Khoya Paneer':320,'Kaju Curry':320,'Paneer Bhurji':310,'Malai Kofta':265,'Mixed Veg':245}
r11['main course']['Dal']={'Dal Jeera Fry':150,'Dal Tadka':185,'Dal Makhani':195,'Dal Palak':195,'Dal Punjabi Tadka':205,'Dal Vrindavan':240}
r11['thali']={'Paneer Do Piyaja + 3 Tawa Paratha + Kachumber Salad':135,'Paneer Chatpata + 3 Tawa Paratha + Kachumber Salad':135,'Paneer Indori + 3 Tawa Paratha + Kachumber Salad':135,'Sev Tamatar + 3 Tawa Paratha + Kachumber Salad':129,'Dum Aloo Bhojpuri + 3 Tawa Paratha + Kachumber Salad':129,'Bhindi Do Piyaja + 3 Tawa Paratha + Kachumber Salad':129,'Aloo Gobi + 3 Tawa Paratha + Kachumber Salad':129}
r11['biryani']={'Sabji Biryani':225,'Mushroom Biryani':240,'Vrindavan Biryani':245}
r11['rice']={'Steamed Rice':140,'Jeera Rice':150,'Veg Pulao':185,'Peas Pulao':185,'Kashmiri Pulao':245,'Veg Fried Rice':245,'Schezwan Fried Rice':160,'Veg Noodles':225}
r11['breads']={'Tandoori Roti':20,'Tandoori Butter Roti':25,'Missi Roti':30,'Khasta Roti':30,'Plain Naan':40,'Butter Naan':45,'Cheese Chilli Garlic Naan':95,'Garlic Naan':75,'Cheese Chilli Naan':105}
r11['sides']={}
r11['sides']['Quick Bites']={'Peanut Chaat':95,'Finger Chips':95,'Aloo Chaat':75,'Chana Chaat':95,'Masala Wedges':150,'Cheese Nuggets':185}
r11['sides']['Salads']={'Green Chilli Fried Salad':65,'Garden Fresh Green Salad':75,'Punjabi Salad':75,'Cabbage Pineapple Salad':115,'Corn Pineapple Salad':115}
r11['desserts']={'Shrikhand':110,'Gulab Jmaun':110,'Gulab Jmaun with Ice Cream':140}
r11['beverages']={'Hot':{'Lemon Tea':40,'Black Tea':40,'Masala Tea':40,'Coffee':50},'Cold':{'Milk Shake':125,'Cold Coffee':125},'Refreshments':{'Jal Jeera':75,'Cumint Masala Crunch':80,'Mint Masala Crunch':80,'Lassi':105,'Lime Water':40,'Canned Juice':125,'Butter Milk':25}}
f=open('R.py','w+')
f.truncate(0)
f.write(json.dumps(r11))
f.close()