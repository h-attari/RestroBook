from django.shortcuts import redirect,render
import mysql.connector as mysql
from RestroBook import views as Rviews

def home(req):
	countries = Rviews.locations()
	user = []
	if req.session.has_key('id'):
		user.append(req.session['id'])
		user.append(req.session['name'])
	return render(req,'home.html', {"Location":countries, "user":user})

def login(req):
	cred = []
	cred.append(req.POST.get("lmail"))
	cred.append(req.POST.get("pswd"))
	Rviews.logintask(req, cred)
	return redirect('/user/home')

def sign(req):
	cred = []
	cred.append(req.POST.get("fname"))
	cred.append(req.POST.get("lname"))
	cred.append(req.POST.get("mob"))
	cred.append(req.POST.get("smail"))
	cred.append(req.POST.get("pswrd"))
	Rviews.signtask(req, cred)
	return redirect('/user/home')

def forgot(req):
	Rviews.forgot(req, req.POST.get("forgotmail"))
	return redirect('/user/home')

def about(req):
	user = []
	if req.session.has_key('id'):
		user.append(req.session['id'])
		user.append(req.session['name'])
	return render(req,'about.html', {"user":user})

def contact(req):
	user = []
	if req.session.has_key('id'):
		user.append(req.session['id'])
		user.append(req.session['name'])
	return render(req,'contact.html', {"user":user})

def reward(req):
	user = []
	if req.session.has_key('id'):
		user.append(req.session['id'])
		user.append(req.session['name'])
	return render(req, 'rewards.html', {"user":user})

def bookings(req):
	user = []
	if req.session.has_key('id'):
		user.append(req.session['id'])
		user.append(req.session['name'])
	return render(req,'bookings.html', {"user":user})

def query(req):
	conn = mysql.connect(host="localhost",user="root",password="root",database="RestroBook")
	cr = conn.cursor()
	first = req.POST.get("firstname")
	last = req.POST.get("lastname")
	mob = req.POST.get("mobnum")
	mail = req.POST.get("emailid")
	query = req.POST.get("query")
	qu = "select user_id from users where first_name=%s and last_name=%s and mobile=%s and email=%s"
	v = (first, last, mob, mail)
	cr.execute(qu,v)
	rec = cr.fetchone()
	if rec == None:
		name = first + ' ' + last
		qu = "insert into queries(name, mobile, email, query_details) values('{0}','{1}','{2}','{3}')".format(name,mob,mail,query)
		cr.execute(qu)
	else:
		qu = "insert into queries(user_id, query_details) values('{0}','{1}')".format(rec[0],query)
		cr.execute(qu)
	conn.commit()
	conn.close()
	return redirect('/user/contact')

def payment(req):
	return render(req,'payment.html')