from django.shortcuts import redirect,render
import mysql.connector as mysql
from RestroBook import views as Rviews

def restaurants():
	conn = mysql.connect(host="localhost",user="root",password="root",database="RestroBook")
	cr = conn.cursor()
	qu = "select rest_id,rest_name,address,email,mobile from restaurants"
	cr.execute(qu)
	rec = cr.fetchall()
	rstrnt = {}
	for x in rec:
		qu = "select country_name from country where country=(select country from restaurants where rest_id=%s)"
		v = (x[0],)
		cr.execute(qu,v)
		cntry = cr.fetchone()
		qu = "select city_name from city where city=(select city from restaurants where rest_id=%s)"
		v = (x[0],)
		cr.execute(qu,v)
		cit = cr.fetchone()
		rstrnt[x[0]] = [x[1],x[2],x[3],x[4],cit[0],cntry[0]]		
	conn.close()
	return rstrnt

def home(req):
	countries = Rviews.locations()
	rstrnt = restaurants()
	user = []
	if req.session.has_key('id'):
		user.append(req.session['id'])
		user.append(req.session['name'])
	return render(req,'home.html', {"Location":countries, "user":user, "rstrnt":rstrnt})

def login(req):
	cred = []
	cred.append(req.POST.get("lmail"))
	cred.append(req.POST.get("pswd"))
	Rviews.logintask(req, cred)
	return redirect('/user/home')

def sign(req):
	cred = []
	cred.append(req.POST.get("fname"))
	cred.append(req.POST.get("lname"))
	cred.append(req.POST.get("mob"))
	cred.append(req.POST.get("smail"))
	cred.append(req.POST.get("pswrd"))
	Rviews.signtask(req, cred)
	return redirect('/user/home')

def forgot(req):
	Rviews.forgot(req, req.POST.get("forgotmail"))
	return redirect('/user/home')

def about(req):
	user = []
	if req.session.has_key('id'):
		user.append(req.session['id'])
		user.append(req.session['name'])
	return render(req,'about.html', {"user":user})

def contact(req):
	user = []
	if req.session.has_key('id'):
		user.append(req.session['id'])
		user.append(req.session['name'])
	return render(req,'contact.html', {"user":user})

def reward(req):
	user = []
	if req.session.has_key('id'):
		user.append(req.session['id'])
		user.append(req.session['name'])
	return render(req, 'rewards.html', {"user":user})

def bookings(req):
	user = []
	if req.session.has_key('id'):
		user.append(req.session['id'])
		user.append(req.session['name'])
	return render(req,'bookings.html', {"user":user})

def query(req):
	conn = mysql.connect(host="localhost",user="root",password="root",database="RestroBook")
	cr = conn.cursor()
	first = req.POST.get("firstname")
	last = req.POST.get("lastname")
	mob = req.POST.get("mobnum")
	mail = req.POST.get("emailid")
	query = req.POST.get("query")
	qu = "select user_id from users where first_name=%s and last_name=%s and mobile=%s and email=%s"
	v = (first, last, mob, mail)
	cr.execute(qu,v)
	rec = cr.fetchone()
	if rec == None:
		name = first + ' ' + last
		qu = "insert into queries(name, mobile, email, query_details) values('{0}','{1}','{2}','{3}')".format(name,mob,mail,query)
		cr.execute(qu)
	else:
		qu = "insert into queries(user_id, query_details) values('{0}','{1}')".format(rec[0],query)
		cr.execute(qu)
	conn.commit()
	conn.close()
	return redirect('/user/contact')

def payment(req):
	return render(req,'payment.html')

def bill(req):
	return render(req,'bill.html')