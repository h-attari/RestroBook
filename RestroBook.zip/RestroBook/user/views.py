from django.shortcuts import redirect,render
from RestroBook import views as Rviews

def home(req):
	countries = Rviews.locations()
	return render(req,'home.html', {"Location":countries})

def login(req):
	Rviews.logintask()
	return redirect('/user/home')

def sign(req):
	Rviews.signtask(req)
	return redirect('/user/home')

def payment(req):
	return render(req,'payment.html')