from django.shortcuts import redirect,render
import mysql.connector as mysql
from RestroBook import views as Rviews
from datetime import date, datetime, timedelta
import smtplib
from email.mime.text import MIMEText

def creduser(req):
	user = []
	if req.session.has_key('id'):
		user.append(req.session['id'])
		user.append(req.session['name'])
	return user

def restaurants():
	conn = mysql.connect(host="localhost",user="root",password="root",database="RestroBook")
	cr = conn.cursor()
	qu = "select rest_id,rest_name,address,email,mobile from restaurants"
	cr.execute(qu)
	rec = cr.fetchall()
	rstrnt = {}
	for x in rec:
		qu = "select country_name from country where country=(select country from restaurants where rest_id=%s)"
		v = (x[0],)
		cr.execute(qu,v)
		cntry = cr.fetchone()
		qu = "select city_name from city where city=(select city from restaurants where rest_id=%s)"
		v = (x[0],)
		cr.execute(qu,v)
		cit = cr.fetchone()
		path = "./RestroBook/static/dscrp/"+x[0]+".txt"
		f = open(path,'r')
		abt = f.read()
		rstrnt[x[0]] = [x[1],x[2],x[3],x[4],cit[0],cntry[0],abt]
	conn.close()
	return rstrnt

def home(req):
	countries = Rviews.locations()
	rstrnt = restaurants()
	user = creduser(req)
	return render(req,'home.html', {"Location":countries, "user":user, "rstrnt":rstrnt})

def login(req):
	cred = []
	cred.append(req.POST.get("lmail"))
	cred.append(req.POST.get("pswd"))
	Rviews.logintask(req, cred)
	return redirect('/user/home')

def sign(req):
	cred = []
	cred.append(req.POST.get("fname"))
	cred.append(req.POST.get("lname"))
	cred.append(req.POST.get("mob"))
	cred.append(req.POST.get("smail"))
	cred.append(req.POST.get("pswrd"))
	Rviews.signtask(req, cred)
	return redirect('/user/home')

def forgot(req):
	Rviews.forgot(req, req.POST.get("forgotmail"))
	return redirect('/user/home')

def about(req):
	user = creduser(req)
	return render(req,'about.html', {"user":user})

def contact(req):
	user = creduser(req)
	if user:
		conn = mysql.connect(host="localhost",user="root",password="root",database="RestroBook")
		cr = conn.cursor()
		qu = "select first_name,last_name,mobile,email from users where user_id=%s"
		v = (user[0],)
		cr.execute(qu,v)
		rec = cr.fetchone()
		return render(req,'contact.html', {"user":user,"rec":rec})
	return render(req,'contact.html', {"user":user})

def reward(req):
	user = creduser(req)
	rwrds = {}
	if user:
		conn = mysql.connect(host="localhost",user="root",password="root",database="RestroBook")
		cr = conn.cursor()
		qu = "select reward_id from reward_link where user_id=%s"
		v = (user[0],)
		cr.execute(qu,v)
		rec = cr.fetchall()
		if rec != None:
			i = 1
			for x in rec:
				qu = "select reward_details from rewards where reward_id=%s"
				v = (x[0],)
				cr.execute(qu,v)
				temp = cr.fetchone()
				temp = temp[0].split('Valid')
				if len(temp) > 1:
					temp[1] = 'Valid '+temp[1]
				else:
					temp.append("-------")
				rwrds[i] = temp
				i += 1
	return render(req, 'rewards.html', {"user":user, "rwrds":rwrds})

def bookings(req):
	user = creduser(req)
	if user:
		conn = mysql.connect(host="localhost",user="root",password="root",database="RestroBook")
		cr = conn.cursor()
		qu = "select * from booking where user_id=%s and pending=%s order by booking_date desc"
		v = (user[0],0)
		cr.execute(qu,v)
		rec = cr.fetchall()
		b_data = []
		for x in rec:
			qu = "select * from restaurants where rest_id=%s"
			v = (x[6],)
			cr.execute(qu,v)
			rest = cr.fetchone()
			qu = "select city_name from city where city=%s"
			v = (rest[3],)
			cr.execute(qu,v)
			city = cr.fetchone()
			qu = "select country_name from country where country=%s"
			v = (rest[2],)
			cr.execute(qu,v)
			cntry = cr.fetchone()
			temp = list(x)
			temp[6] = (rest[1],rest[0],rest[5],rest[6],rest[4],city[0],cntry[0])
			if temp[8] == "debit":
				temp[8] = "Debit Card"
			elif temp[8] == "credit":
				temp[8] = "Credit Card"
			else:
				temp[8] = "Net Banking"
			cancel = 0
			if x[3] > date.today():
				cancel = 1
			elif x[3] == date.today():
				now = datetime.now()
				limit = timedelta(hours = int(now.strftime("%H"))+2) + timedelta(minutes = int(now.strftime("%M"))) + timedelta(seconds = int(now.strftime("%S")))
				if limit <= x[4]:
					cancel = 1
			temp.append(cancel)
			b_data.append(temp)
		conn.close()
		return render(req,'bookings.html', {"user":user,"rec":b_data})
	else:
		return render(req,'bookings.html',{"user":user})

def query(req):
	user = creduser(req)
	conn = mysql.connect(host="localhost",user="root",password="root",database="RestroBook")
	cr = conn.cursor()
	flag = req.POST.get("datacheckbox")
	query = req.POST.get("query")
	if flag:
		qu = 'insert into queries(user_id, query_details) values("{0}","{1}")'.format(user[0],query)
		cr.execute(qu)
	else:
		first = req.POST.get("firstname")
		last = req.POST.get("lastname")
		mob = req.POST.get("mobnum")
		mail = req.POST.get("emailid")
		name = first + ' ' + last
		qu = "insert into queries(name, mobile, email, query_details) values('{0}','{1}','{2}','{3}')".format(name,mob,mail,query)
		cr.execute(qu)
	conn.commit()
	conn.close()
	return redirect('/user/contact')

def payment(req):
	user = creduser(req)
	restid = req.POST.get("rest_id")
	restname = req.POST.get("rest_name")
	total = req.POST.get("total")
	guest = req.POST.get("guest")
	date = req.POST.get("date")
	time = req.POST.get("time")
	menu = req.POST.get("menu")
	bill = req.POST.get("bill")
	return render(req,'payment.html',{"data":[user[0],restid,restname,total,guest,date,time,menu,bill]})

def bill(req):
	user = creduser(req)
	conn = mysql.connect(host="localhost",user="root",password="root",database="RestroBook")
	cr = conn.cursor()
	menu = []
	restid = req.POST.get("restdata")
	date = req.POST.get("date")
	time = req.POST.get("time")
	guest = req.POST.get("guest")
	qu = "select rest_name,bookrate from restaurants where rest_id=%s"
	v = (restid,)
	cr.execute(qu,v)
	restdata = cr.fetchone()
	osc = restdata[1]*0.005
	return render(req,'bill.html',{"rest_data":[restid,restdata[0],date,time,guest], "pay":[restdata[1],osc,restdata[1]+osc], "menu":menu})

def search(req):
	user = creduser(req)
	rstrnt = {}
	conn = mysql.connect(host="localhost",user="root",password="root",database="RestroBook")
	cr = conn.cursor(buffered=True)
	loc = req.GET.get("location")
	rest = req.GET.get("restaurant")
	if loc == '' and rest == '':
		return redirect('/user/home')
	elif loc == '':
		rest = '%'+rest+'%'
		qu = "select rest_id,rest_name,address,country,city,email,mobile from restaurants where rest_name like %s"
		v = (rest,)
		cr.execute(qu,v)
		rec = cr.fetchone()
		if rec != None:
			rstrnt[rec[0]] = [rec[1],rec[2],rec[5],rec[6]]
			qu = "select country_name from country where country=%s"
			v = (rec[3],)
			cr.execute(qu,v)
			cntry = cr.fetchone()
			rstrnt[rec[0]].append(cntry[0])
			qu = "select city_name from city where city=%s"
			v = (rec[4],)
			cr.execute(qu,v)
			city = cr.fetchone()
			rstrnt[rec[0]].append(city[0])
			path = "./RestroBook/static/dscrp/"+rec[0]+".txt"
			f = open(path,'r')
			abt = f.read()
			rstrnt[rec[0]].append(abt)
		else:
			conn.close()
			return render(req,'search.html',{"user":user, "rstrnt":rstrnt})
	elif rest == '':
		qu = "select country from country where country_name=%s"
		v = (loc,)
		cr.execute(qu,v)
		rec = cr.fetchone()
		if rec != None:
			qu = "select rest_id,rest_name,address,city,email,mobile from restaurants where country=%s"
			v = (rec[0],)
			cr.execute(qu,v)
			rst = cr.fetchall()
			if rst == None:
				conn.close()
				return render(req,'search.html',{"user":user, "rstrnt":rstrnt})
			for x in rst:
				rstrnt[x[0]] = [x[1],x[2],x[4],x[5],loc.capitalize()]
				qu = "select city_name from city where city=%s"
				v = (x[3],)
				cr.execute(qu,v)
				city = cr.fetchone()
				rstrnt[x[0]].append(city[0])
				path = "./RestroBook/static/dscrp/"+x[0]+".txt"
				f = open(path,'r')
				abt = f.read()
				rstrnt[x[0]].append(abt)
		else:
			qu = "select city from city where city_name=%s"
			v = (loc,)
			cr.execute(qu,v)
			rec = cr.fetchone()
			if rec == None:
				conn.close()
				return render(req,'search.html',{"user":user, "rstrnt":rstrnt})
			else:
				qu = "select rest_id,rest_name,address,country,email,mobile from restaurants where city=%s"
				v = (rec[0],)
				cr.execute(qu,v)
				rst = cr.fetchall()
				if rst == None:
					conn.close()
					return render(req,'search.html',{"user":user, "rstrnt":rstrnt})
				else:
					for x in rst:
						rstrnt[x[0]] = [x[1],x[2],x[4],x[5]]
						qu = "select country_name from country where country=%s"
						v = (x[3],)
						cr.execute(qu,v)
						cntry = cr.fetchone()
						rstrnt[x[0]].append(cntry[0])
						rstrnt[x[0]].append(loc.capitalize())
						path = "./RestroBook/static/dscrp/"+x[0]+".txt"
						f = open(path,'r')
						abt = f.read()
						rstrnt[x[0]].append(abt)
	else:
		rest = '%'+rest+'%'
		qu = "select rest_id,rest_name,address,country,city,email,mobile from restaurants where rest_name like %s"
		v = (rest,)
		cr.execute(qu,v)
		rec = cr.fetchall()
		if rec == None:
			conn.close()
			return render(req,'search.html',{"user":user, "rstrnt":rstrnt})
		for x in rec:
			qu = "select country_name from country where country=%s"
			v = (x[3],)
			cr.execute(qu,v)
			cntry = cr.fetchone()
			qu = "select city_name from city where city=%s"
			v = (x[4],)
			cr.execute(qu,v)
			city = cr.fetchone()
			if city[0] == loc or cntry[0] == loc:
				path = "./RestroBook/static/dscrp/"+x[0]+".txt"
				f = open(path,'r')
				abt = f.read()
				rstrnt[x[0]] = [x[1],x[2],x[5],x[6],cntry[0],city[0],abt]
			else:
				conn.close()
				return render(req,'search.html',{"user":user, "rstrnt":rstrnt})
	conn.close()
	return render(req,'search.html',{"user":user, "rstrnt":rstrnt})

def success(req):
	user = creduser(req)
	conn = mysql.connect(host="localhost",user="root",password="root",database="RestroBook")
	cr = conn.cursor()
	paytype = req.POST.get("paytype")
	restid = req.POST.get("rest")
	total = req.POST.get("total")
	total = float(total)
	guest = req.POST.get("guest")
	bdate = req.POST.get("date")
	time = req.POST.get("time")
	menu = req.POST.get("menu")
	bill = req.POST.get("bill")
	book_id = user[0][:2] + user[0][4:6] + bdate[5:7] + bdate[8:] + restid
	today = date.today()
	qu = "select rest_name from restaurants where rest_id=%s"
	v = (restid,)
	cr.execute(qu,v)
	restname = cr.fetchone()
	if menu != '[]':
		bill = float(bill)
		qu = "insert into booking(book_id,guests,booking_date,date,time,user_id,rest_id,menu,paytype,book_amount,bill_amount,pending) values('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}','{10}','{11}')".format(book_id,guest,today,bdate,time,user[0],restid,menu,paytype,total,bill,1)
	else:
		qu = "insert into booking(book_id,guests,booking_date,date,time,user_id,rest_id,paytype,book_amount,pending) values('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}')".format(book_id,guest,today,bdate,time,user[0],restid,paytype,total,1)
	cr.execute(qu)
	conn.commit()
	conn.close()
	return render(req,"success.html",{"book":[book_id,guest,bdate,time,restname[0]]})

def mails(user,mail,rest,guest,date,time):
	server = smtplib.SMTP('smtp.gmail.com', 587)
	html="""
	<html>
		<body>
			<div>
				<p style="font-size:18px;">
					Welcome <i>{0}</i>!
				</p>
				<br><br>
				<p style="font-size:16px;">
					Your table booking in <strong>{1}</strong> for <strong>{2}</strong> people for Date: <strong>{3}</strong> &amp; Time: <strong>{4}</strong> has been <strong>Cancelled</strong> successfully.<br>The booking amount will be refunded within 3 working days.
				</p>
			</div>
		</body>
	</html>""".format(user,rest,guest,date,time)
	msg=MIMEText(html, 'html')
	server.starttls()
	server.login("hlucifer44@gmail.com", "1060543987")
	server.sendmail("hlucifer44@gmail.com", mail, msg.as_string())
	server.quit()

def cancel(req):
	user = creduser(req)
	conn = mysql.connect(host="localhost",user="root",password="root",database="RestroBook")
	cr = conn.cursor()
	bookid = req.POST.get("cancel")
	qu = "select rest_id,date,time,guests from booking where book_id=%s"
	v = (bookid,)
	cr.execute(qu,v)
	rec = cr.fetchone()
	qu = "select rest_name from restaurants where rest_id=%s"
	v = (rec[0],)
	cr.execute(qu,v)
	rest = cr.fetchone()
	qu = "select email from users where user_id=%s"
	v = (user[0],)
	cr.execute(qu,v)
	mail = cr.fetchone()
	mails(user[1],mail[0],rest[0],rec[3],rec[1],rec[2])
	qu = "delete from booking where book_id=%s"
	v = (bookid,)
	cr.execute(qu,v)
	conn.commit()
	conn.close()
	return redirect('/user/bookings')