from django.shortcuts import redirect,render
from RestroBook import views as Rviews

def home(req):
	countries = Rviews.locations()
	return render(req,'home.html', {"Location":countries})

def login(req):
	cred = []
	cred.append(req.POST.get("lmail"))
	cred.append(req.POST.get("pswd"))
	Rviews.logintask(req, cred)
	return redirect('/user/home')

def sign(req):
	cred = []
	cred.append(req.POST.get("fname"))
	cred.append(req.POST.get("lname"))
	cred.append(req.POST.get("mob"))
	cred.append(req.POST.get("smail"))
	cred.append(req.POST.get("pswrd"))
	Rviews.signtask(req, cred)
	return redirect('/user/home')

def about(req):
	return render(req,'about.html')

def contact(req):
	return render(req,'contact.html')

def payment(req):
	return render(req,'payment.html')