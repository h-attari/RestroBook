from django.shortcuts import redirect,render
import mysql.connector as mysql
from RestroBook import views as Rviews
import os

def creduser(req):
	user = []
	if req.session.has_key('id'):
		user.append(req.session['id'])
		user.append(req.session['name'])
	return user

def restaurants():
	conn = mysql.connect(host="localhost",user="root",password="root",database="RestroBook")
	cr = conn.cursor()
	qu = "select rest_id,rest_name,address,email,mobile from restaurants"
	cr.execute(qu)
	rec = cr.fetchall()
	rstrnt = {}
	for x in rec:
		qu = "select country_name from country where country=(select country from restaurants where rest_id=%s)"
		v = (x[0],)
		cr.execute(qu,v)
		cntry = cr.fetchone()
		qu = "select city_name from city where city=(select city from restaurants where rest_id=%s)"
		v = (x[0],)
		cr.execute(qu,v)
		cit = cr.fetchone()
		path = "./RestroBook/static/dscrp/"+x[0]+".txt"
		f = open(path,'r')
		abt = f.read()
		rstrnt[x[0]] = [x[1],x[2],x[3],x[4],cit[0],cntry[0],abt]
	conn.close()
	return rstrnt

def home(req):
	countries = Rviews.locations()
	rstrnt = restaurants()
	user = creduser(req)
	return render(req,'home.html', {"Location":countries, "user":user, "rstrnt":rstrnt})

def login(req):
	cred = []
	cred.append(req.POST.get("lmail"))
	cred.append(req.POST.get("pswd"))
	Rviews.logintask(req, cred)
	return redirect('/user/home')

def sign(req):
	cred = []
	cred.append(req.POST.get("fname"))
	cred.append(req.POST.get("lname"))
	cred.append(req.POST.get("mob"))
	cred.append(req.POST.get("smail"))
	cred.append(req.POST.get("pswrd"))
	Rviews.signtask(req, cred)
	return redirect('/user/home')

def forgot(req):
	Rviews.forgot(req, req.POST.get("forgotmail"))
	return redirect('/user/home')

def about(req):
	user = creduser(req)
	return render(req,'about.html', {"user":user})

def contact(req):
	user = creduser(req)
	return render(req,'contact.html', {"user":user})

def reward(req):
	user = creduser(req)
	rwrds = {}
	if user:
		conn = mysql.connect(host="localhost",user="root",password="root",database="RestroBook")
		cr = conn.cursor()
		qu = "select reward_id from reward_link where user_id=%s"
		v = (user[0],)
		cr.execute(qu,v)
		rec = cr.fetchall()
		if rec != None:
			i = 1
			for x in rec:
				qu = "select reward_details from rewards where reward_id=%s"
				v = (x[0],)
				cr.execute(qu,v)
				temp = cr.fetchone()
				temp = temp[0].split('Valid')
				temp[1] = 'Valid '+temp[1]
				rwrds[i] = temp
				i += 1
	return render(req, 'rewards.html', {"user":user, "rwrds":rwrds})

def bookings(req):
	user = creduser(req)
	return render(req,'bookings.html', {"user":user})

def query(req):
	conn = mysql.connect(host="localhost",user="root",password="root",database="RestroBook")
	cr = conn.cursor()
	first = req.POST.get("firstname")
	last = req.POST.get("lastname")
	mob = req.POST.get("mobnum")
	mail = req.POST.get("emailid")
	query = req.POST.get("query")
	qu = "select user_id from users where first_name=%s and last_name=%s and mobile=%s and email=%s"
	v = (first, last, mob, mail)
	cr.execute(qu,v)
	rec = cr.fetchone()
	if rec == None:
		name = first + ' ' + last
		qu = "insert into queries(name, mobile, email, query_details) values('{0}','{1}','{2}','{3}')".format(name,mob,mail,query)
		cr.execute(qu)
	else:
		qu = "insert into queries(user_id, query_details) values('{0}','{1}')".format(rec[0],query)
		cr.execute(qu)
	conn.commit()
	conn.close()
	return redirect('/user/contact')

def payment(req):
	user = creduser(req)
	return render(req,'payment.html')

def bill(req):
	user = creduser(req)
	conn = mysql.connect(host="localhost",user="root",password="root",database="RestroBook")
	cr = conn.cursor()
	menu = []
	restid = req.POST.get("restdata")
	date = req.POST.get("date")
	time = req.POST.get("time")
	guest = req.POST.get("guest")
	qu = "select rest_name from restaurants where rest_id=%s"
	v = (restid,)
	cr.execute(qu,v)
	restname = cr.fetchone()
	restname = restname[0]
	return render(req,'bill.html',{"rest_data":[restid,restname,date,time,guest], "menu":menu})

def search(req):
	user = creduser(req)
	rstrnt = {}
	conn = mysql.connect(host="localhost",user="root",password="root",database="RestroBook")
	cr = conn.cursor(buffered=True)
	loc = req.GET.get("location")
	rest = req.GET.get("restaurant")
	if loc == '' and rest == '':
		return redirect('/user/home')
	elif loc == '':
		rest = '%'+rest+'%'
		qu = "select rest_id,rest_name,address,country,city,email,mobile from restaurants where rest_name like %s"
		v = (rest,)
		cr.execute(qu,v)
		rec = cr.fetchone()
		if rec != None:
			rstrnt[rec[0]] = [rec[1],rec[2],rec[5],rec[6]]
			qu = "select country_name from country where country=%s"
			v = (rec[3],)
			cr.execute(qu,v)
			cntry = cr.fetchone()
			rstrnt[rec[0]].append(cntry[0])
			qu = "select city_name from city where city=%s"
			v = (rec[4],)
			cr.execute(qu,v)
			city = cr.fetchone()
			rstrnt[rec[0]].append(city[0])
			path = "./RestroBook/static/dscrp/"+x[0]+".txt"
			f = open(path,'r')
			abt = f.read()
			rstrnt[rec[0]].append(abt)
		else:
			conn.close()
			return render(req,'search.html',{"user":user, "rstrnt":rstrnt})
	elif rest == '':
		qu = "select country from country where country_name=%s"
		v = (loc,)
		cr.execute(qu,v)
		rec = cr.fetchone()
		if rec != None:
			qu = "select rest_id,rest_name,address,city,email,mobile from restaurants where country=%s"
			v = (rec[0],)
			cr.execute(qu,v)
			rst = cr.fetchall()
			if rst == None:
				conn.close()
				return render(req,'search.html',{"user":user, "rstrnt":rstrnt})
			for x in rst:
				rstrnt[x[0]] = [x[1],x[2],x[4],x[5],loc.capitalize()]
				qu = "select city_name from city where city=%s"
				v = (x[3],)
				cr.execute(qu,v)
				city = cr.fetchone()
				rstrnt[x[0]].append(city[0])
				path = "./RestroBook/static/dscrp/"+x[0]+".txt"
				f = open(path,'r')
				abt = f.read()
				rstrnt[x[0]].append(abt)
		else:
			qu = "select city from city where city_name=%s"
			v = (loc,)
			cr.execute(qu,v)
			rec = cr.fetchone()
			if rec == None:
				conn.close()
				return render(req,'search.html',{"user":user, "rstrnt":rstrnt})
			else:
				qu = "select rest_id,rest_name,address,country,email,mobile from restaurants where city=%s"
				v = (rec[0],)
				cr.execute(qu,v)
				rst = cr.fetchall()
				if rst == None:
					conn.close()
					return render(req,'search.html',{"user":user, "rstrnt":rstrnt})
				else:
					for x in rst:
						rstrnt[x[0]] = [x[1],x[2],x[4],x[5]]
						qu = "select country_name from country where country=%s"
						v = (x[3],)
						cr.execute(qu,v)
						cntry = cr.fetchone()
						rstrnt[x[0]].append(cntry[0])
						rstrnt[x[0]].append(loc.capitalize())
						path = "./RestroBook/static/dscrp/"+x[0]+".txt"
						f = open(path,'r')
						abt = f.read()
						rstrnt[x[0]].append(abt)
	else:
		rest = '%'+rest+'%'
		qu = "select rest_id,rest_name,address,country,city,email,mobile from restaurants where rest_name like %s"
		v = (rest,)
		cr.execute(qu,v)
		rec = cr.fetchall()
		if rec == None:
			conn.close()
			return render(req,'search.html',{"user":user, "rstrnt":rstrnt})
		for x in rec:
			qu = "select country_name from country where country=%s"
			v = (x[3],)
			cr.execute(qu,v)
			cntry = cr.fetchone()
			qu = "select city_name from city where city=%s"
			v = (x[4],)
			cr.execute(qu,v)
			city = cr.fetchone()
			if city[0] == loc or cntry[0] == loc:
				path = "./RestroBook/static/dscrp/"+x[0]+".txt"
				f = open(path,'r')
				abt = f.read()
				rstrnt[x[0]] = [x[1],x[2],x[5],x[6],cntry[0],city[0],abt]
			else:
				conn.close()
				return render(req,'search.html',{"user":user, "rstrnt":rstrnt})
	conn.close()
	return render(req,'search.html',{"user":user, "rstrnt":rstrnt})