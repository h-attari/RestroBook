-- MySQL dump 10.13  Distrib 8.0.18, for Win64 (x86_64)
--
-- Host: localhost    Database: restrobook
-- ------------------------------------------------------
-- Server version	8.0.18

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin` (
  `admin_id` varchar(10) NOT NULL,
  `first_name` varchar(20) DEFAULT NULL,
  `last_name` varchar(20) DEFAULT NULL,
  `mobile` varchar(10) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `pswrd` varchar(16) DEFAULT NULL,
  PRIMARY KEY (`admin_id`),
  UNIQUE KEY `account` (`first_name`,`last_name`,`mobile`,`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `city`
--

DROP TABLE IF EXISTS `city`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `city` (
  `city` int(10) NOT NULL AUTO_INCREMENT,
  `city_name` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`city`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `city`
--

LOCK TABLES `city` WRITE;
/*!40000 ALTER TABLE `city` DISABLE KEYS */;
INSERT INTO `city` VALUES (1,'Indore'),(2,'Udaipur'),(3,'Paris'),(4,'Bordeaux'),(5,'Barcelona'),(6,'Seville'),(7,'New York City'),(8,'Los Angeles'),(9,'Las Vegas'),(10,'Monterrey'),(11,'Rio de Janerio'),(12,'Turku'),(13,'Helsinki'),(14,'Italy'),(15,'Capranica'),(16,'Bengluru'),(17,'Pune'),(18,'Surat'),(19,'Hyderabad'),(20,'Lyon');
/*!40000 ALTER TABLE `city` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `country`
--

DROP TABLE IF EXISTS `country`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `country` (
  `country` int(10) NOT NULL AUTO_INCREMENT,
  `country_name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`country`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `country`
--

LOCK TABLES `country` WRITE;
/*!40000 ALTER TABLE `country` DISABLE KEYS */;
INSERT INTO `country` VALUES (1,'India'),(2,'France'),(3,'America'),(4,'Rome'),(5,'Brazil'),(6,'Mexico'),(7,'Spain'),(8,'Singapore'),(9,'Finland'),(10,'Canada');
/*!40000 ALTER TABLE `country` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `offer_link`
--

DROP TABLE IF EXISTS `offer_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `offer_link` (
  `offer_id` int(10) DEFAULT NULL,
  `rest_id` varchar(10) DEFAULT NULL,
  `user_id` varchar(10) DEFAULT NULL,
  KEY `offer_id` (`offer_id`),
  KEY `rest_id` (`rest_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `offer_link_ibfk_1` FOREIGN KEY (`offer_id`) REFERENCES `offers` (`offer_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `offer_link_ibfk_2` FOREIGN KEY (`rest_id`) REFERENCES `restaurants` (`rest_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `offer_link_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `offer_link`
--

LOCK TABLES `offer_link` WRITE;
/*!40000 ALTER TABLE `offer_link` DISABLE KEYS */;
/*!40000 ALTER TABLE `offer_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `offers`
--

DROP TABLE IF EXISTS `offers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `offers` (
  `offer_id` int(10) NOT NULL AUTO_INCREMENT,
  `offer_details` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`offer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `offers`
--

LOCK TABLES `offers` WRITE;
/*!40000 ALTER TABLE `offers` DISABLE KEYS */;
/*!40000 ALTER TABLE `offers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `queries`
--

DROP TABLE IF EXISTS `queries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `queries` (
  `query_id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) DEFAULT NULL,
  `mobile` varchar(10) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `query_details` varchar(150) DEFAULT NULL,
  `user_id` varchar(10) DEFAULT NULL,
  `rest_id` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`query_id`),
  KEY `user_id` (`user_id`),
  KEY `rest_id` (`rest_id`),
  CONSTRAINT `queries_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `queries_ibfk_2` FOREIGN KEY (`rest_id`) REFERENCES `restaurants` (`rest_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `queries`
--

LOCK TABLES `queries` WRITE;
/*!40000 ALTER TABLE `queries` DISABLE KEYS */;
/*!40000 ALTER TABLE `queries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rating_link`
--

DROP TABLE IF EXISTS `rating_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rating_link` (
  `user_id` varchar(10) DEFAULT NULL,
  `rest_id` varchar(10) DEFAULT NULL,
  `rating_id` int(10) DEFAULT NULL,
  UNIQUE KEY `rate` (`user_id`,`rest_id`),
  KEY `rest_id` (`rest_id`),
  KEY `rating_id` (`rating_id`),
  CONSTRAINT `rating_link_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `rating_link_ibfk_2` FOREIGN KEY (`rest_id`) REFERENCES `restaurants` (`rest_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `rating_link_ibfk_3` FOREIGN KEY (`rating_id`) REFERENCES `ratings` (`rating_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rating_link`
--

LOCK TABLES `rating_link` WRITE;
/*!40000 ALTER TABLE `rating_link` DISABLE KEYS */;
/*!40000 ALTER TABLE `rating_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ratings`
--

DROP TABLE IF EXISTS `ratings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ratings` (
  `rating_id` int(10) NOT NULL AUTO_INCREMENT,
  `rating` float DEFAULT NULL,
  `review` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`rating_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ratings`
--

LOCK TABLES `ratings` WRITE;
/*!40000 ALTER TABLE `ratings` DISABLE KEYS */;
/*!40000 ALTER TABLE `ratings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `restaurants`
--

DROP TABLE IF EXISTS `restaurants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `restaurants` (
  `rest_id` varchar(10) NOT NULL,
  `rest_name` varchar(50) DEFAULT NULL,
  `country` int(10) DEFAULT NULL,
  `city` int(10) DEFAULT NULL,
  `address` varchar(150) DEFAULT NULL,
  `mobile` varchar(10) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `pswrd` varchar(16) DEFAULT NULL,
  PRIMARY KEY (`rest_id`),
  UNIQUE KEY `account` (`rest_name`,`address`,`mobile`,`email`),
  UNIQUE KEY `login` (`pswrd`),
  KEY `country` (`country`),
  KEY `city` (`city`),
  CONSTRAINT `restaurants_ibfk_1` FOREIGN KEY (`country`) REFERENCES `country` (`country`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `restaurants_ibfk_2` FOREIGN KEY (`city`) REFERENCES `city` (`city`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `restaurants`
--

LOCK TABLES `restaurants` WRITE;
/*!40000 ALTER TABLE `restaurants` DISABLE KEYS */;
INSERT INTO `restaurants` VALUES ('R01','Nafees Restaurant',1,1,'Apollo Avenue, 30-B, Greater Kailash Road, New Palasia','9039090005','nafees@gmail.com','nafees123'),('R02','Sayaji Restaurant',1,1,'H/1 , Scheme No.54, Vijay Nagar','7389910949','sayajirest@gmail.com','sayaji123'),('R03','Enrise Restaurant',1,1,'27/1, 27/2, VILLAGE PIGDAMBAR, RAU, TEHSIL MHOW, Mumbai - Agra National Hwy','7314706666','enriserest@gmail.com','enrise123'),('R04','Shreemaya Restaurant',1,1,'12, RNT Marg, South Tukoganj','7314234888','shreemayarest@gmail.com','shreemaya123'),('R05','Daagla Restaurant',1,1,'Hotel Thamla Haveli, Hanuman Ghat, Outside Chandpole','9982988899','daaglarest@gmail.com','daagla123'),('R06','Savya Rasa',1,1,'Gera Serenity Building, CTS No. 15, near Starbucks Cafe, Koregaon Park','9130095522','savyarasa@gmail.com','savya123'),('R07','Barbeque Nation',1,1,'1st Floor, Golden Square, Parle Point Flyover, near Sargam Shopping Center, Athwa','7849006060','barbntn@gmail.com','barbntn123'),('R08','Starbucks Cafe',1,1,'Gera Serenity Building, CTS No. 15, near Starbucks Cafe, Koregaon Park','9130095542','starbucks@gmail.com','star123'),('R09','Central Perk',3,7,'105 Cedarhurst Ave, Cedarhurst, NY 11516','1516374640','centralperk@gmail.com','centralperk123'),('R10','La Patsa Lb',7,5,'Calle Casanova 94, 08011','3493031231','lappatsa@gmail.com','lapatsa123');
/*!40000 ALTER TABLE `restaurants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reward_link`
--

DROP TABLE IF EXISTS `reward_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reward_link` (
  `reward_id` int(10) DEFAULT NULL,
  `user_id` varchar(10) DEFAULT NULL,
  UNIQUE KEY `rewards` (`reward_id`,`user_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `reward_link_ibfk_1` FOREIGN KEY (`reward_id`) REFERENCES `rewards` (`reward_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `reward_link_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reward_link`
--

LOCK TABLES `reward_link` WRITE;
/*!40000 ALTER TABLE `reward_link` DISABLE KEYS */;
/*!40000 ALTER TABLE `reward_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rewards`
--

DROP TABLE IF EXISTS `rewards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rewards` (
  `reward_id` int(10) NOT NULL AUTO_INCREMENT,
  `reward_details` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`reward_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rewards`
--

LOCK TABLES `rewards` WRITE;
/*!40000 ALTER TABLE `rewards` DISABLE KEYS */;
/*!40000 ALTER TABLE `rewards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_feedback`
--

DROP TABLE IF EXISTS `system_feedback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_feedback` (
  `feedback_id` int(10) NOT NULL AUTO_INCREMENT,
  `feedback` varchar(150) DEFAULT NULL,
  `user_id` varchar(10) DEFAULT NULL,
  `rest_id` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`feedback_id`),
  KEY `user_id` (`user_id`),
  KEY `rest_id` (`rest_id`),
  CONSTRAINT `system_feedback_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `system_feedback_ibfk_2` FOREIGN KEY (`rest_id`) REFERENCES `restaurants` (`rest_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_feedback`
--

LOCK TABLES `system_feedback` WRITE;
/*!40000 ALTER TABLE `system_feedback` DISABLE KEYS */;
/*!40000 ALTER TABLE `system_feedback` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `user_id` varchar(10) NOT NULL,
  `first_name` varchar(20) DEFAULT NULL,
  `last_name` varchar(20) DEFAULT NULL,
  `mobile` varchar(10) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `pswrd` varchar(26) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `account` (`first_name`,`last_name`,`mobile`,`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES ('kajh109594','kanak','jhawar','1092387456','kj@jk.com','12345kajh109594'),('kebh998864','keshav','bhutada','9981456555','bhutadakeshav22@gmail.com','keshav22kebh998864'),('miko109921','mitali','koibhi','1092837465','ni@dena.com','12345miko109921'),('Saqw123694','Sakina','qwerty','1234567890','r43@red.com','12345Saqw123694');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-11-01 14:22:54
