-- MySQL dump 10.13  Distrib 8.0.18, for Win64 (x86_64)
--
-- Host: localhost    Database: RestroBook
-- ------------------------------------------------------
-- Server version	8.0.18

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin` (
  `admin_id` varchar(10) NOT NULL,
  `first_name` varchar(20) DEFAULT NULL,
  `last_name` varchar(20) DEFAULT NULL,
  `mobile` varchar(10) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `pswrd` varchar(16) DEFAULT NULL,
  PRIMARY KEY (`admin_id`),
  UNIQUE KEY `account` (`first_name`,`last_name`,`mobile`,`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` VALUES ('admin1','Lucifer','Constantine','1230984756','rj.43@rediffmail.com','lucy');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `booking`
--

DROP TABLE IF EXISTS `booking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `booking` (
  `book_id` varchar(11) NOT NULL,
  `guests` int(50) DEFAULT NULL,
  `booking_date` date DEFAULT NULL,
  `date` date DEFAULT NULL,
  `time` time DEFAULT NULL,
  `user_id` varchar(10) DEFAULT NULL,
  `rest_id` varchar(10) DEFAULT NULL,
  `menu` varchar(2000) DEFAULT NULL,
  `paytype` varchar(20) DEFAULT NULL,
  `book_amount` float DEFAULT NULL,
  `bill_amount` float DEFAULT NULL,
  `pending` int(1) DEFAULT NULL,
  PRIMARY KEY (`book_id`),
  KEY `user_id` (`user_id`),
  KEY `rest_id` (`rest_id`),
  CONSTRAINT `booking_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `booking_ibfk_2` FOREIGN KEY (`rest_id`) REFERENCES `restaurants` (`rest_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `booking`
--

LOCK TABLES `booking` WRITE;
/*!40000 ALTER TABLE `booking` DISABLE KEYS */;
INSERT INTO `booking` VALUES ('as1p1125R12',4,'2020-11-24','2020-11-25','13:44:00','as981po646','R12',NULL,'credit',100.5,NULL,0),('as1p1230R15',4,'2020-12-27','2020-12-30','19:06:00','as981po646','R15','Continental Breakfast-240,French Fries-99,Veg Clear Soup-149,Classic Tomato and Cucumber Sandwich-199,Murgh Tikka-399,Fish Fry-349,Butter Milk Plain/Masala-130','credit',50.25,1565,0),('ka100110R20',10,'2020-12-16','2021-01-10','16:13:00','kajh109594','R20',NULL,'net',60.3,NULL,1),('ke991125R13',4,'2020-11-15','2020-11-25','22:17:00','kebh998864','R13',NULL,'debit',90.45,NULL,0),('ke991201R17',5,'2020-11-16','2020-12-01','00:00:00','kebh998864','R17',NULL,'debit',60.3,NULL,0),('ke991203R18',4,'2020-11-17','2020-12-03','01:35:00','kebh998864','R18',NULL,'credit',80.4,NULL,0),('ke991231R07',3,'2020-12-25','2020-12-31','12:14:00','kebh998864','R07',NULL,'credit',201,NULL,0);
/*!40000 ALTER TABLE `booking` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `city`
--

DROP TABLE IF EXISTS `city`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `city` (
  `city` int(10) NOT NULL AUTO_INCREMENT,
  `city_name` varchar(20) DEFAULT NULL,
  `country` int(10) DEFAULT NULL,
  PRIMARY KEY (`city`),
  KEY `country` (`country`),
  CONSTRAINT `city_ibfk_1` FOREIGN KEY (`country`) REFERENCES `country` (`country`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `city`
--

LOCK TABLES `city` WRITE;
/*!40000 ALTER TABLE `city` DISABLE KEYS */;
INSERT INTO `city` VALUES (1,'Indore',1),(2,'Udaipur',1),(3,'Paris',2),(4,'Bordeaux',2),(5,'Barcelona',7),(6,'Seville',7),(7,'New York City',3),(8,'Los Angeles',3),(9,'Las Vegas',3),(10,'Monterrey',6),(11,'Rio de Janerio',5),(12,'Turku',9),(13,'Helsinki',9),(14,'Italy',4),(15,'Capranica',4),(16,'Bengluru',1),(17,'Pune',1),(18,'Surat',1),(19,'Hyderabad',1),(20,'Lyon',2);
/*!40000 ALTER TABLE `city` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `country`
--

DROP TABLE IF EXISTS `country`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `country` (
  `country` int(10) NOT NULL AUTO_INCREMENT,
  `country_name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`country`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `country`
--

LOCK TABLES `country` WRITE;
/*!40000 ALTER TABLE `country` DISABLE KEYS */;
INSERT INTO `country` VALUES (1,'India'),(2,'France'),(3,'America'),(4,'Rome'),(5,'Brazil'),(6,'Mexico'),(7,'Spain'),(8,'Singapore'),(9,'Finland'),(10,'Canada');
/*!40000 ALTER TABLE `country` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `queries`
--

DROP TABLE IF EXISTS `queries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `queries` (
  `query_id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) DEFAULT NULL,
  `mobile` varchar(10) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `query_details` varchar(150) DEFAULT NULL,
  `user_id` varchar(10) DEFAULT NULL,
  `rest_id` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`query_id`),
  KEY `user_id` (`user_id`),
  KEY `rest_id` (`rest_id`),
  CONSTRAINT `queries_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `queries_ibfk_2` FOREIGN KEY (`rest_id`) REFERENCES `restaurants` (`rest_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `queries`
--

LOCK TABLES `queries` WRITE;
/*!40000 ALTER TABLE `queries` DISABLE KEYS */;
INSERT INTO `queries` VALUES (2,NULL,NULL,NULL,NULL,'kebh998864',NULL),(3,NULL,NULL,NULL,'Testing the user backend query function.','kebh998864',NULL),(4,'arin raj','1029384756','kmld3107@gmai.com','Kanki toh btana.',NULL,NULL),(5,NULL,NULL,NULL,'kanki ko btana part 2','miko109921',NULL),(9,'Without User','1029384756','rj.43@rediffmail.com','Checking again and again.',NULL,NULL),(10,NULL,NULL,NULL,'Let\'s check once again.','raja102885',NULL),(11,NULL,NULL,NULL,'Restaurant query check.',NULL,'R01'),(12,NULL,NULL,NULL,'Query Checking 25 dec.','kebh998864',NULL);
/*!40000 ALTER TABLE `queries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `restaurants`
--

DROP TABLE IF EXISTS `restaurants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `restaurants` (
  `rest_id` varchar(10) NOT NULL,
  `rest_name` varchar(50) DEFAULT NULL,
  `country` int(10) DEFAULT NULL,
  `city` int(10) DEFAULT NULL,
  `address` varchar(150) DEFAULT NULL,
  `mobile` varchar(10) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `pswrd` varchar(16) DEFAULT NULL,
  `bookrate` int(3) DEFAULT NULL,
  PRIMARY KEY (`rest_id`),
  UNIQUE KEY `account` (`rest_name`,`address`,`mobile`,`email`),
  UNIQUE KEY `login` (`pswrd`),
  KEY `country` (`country`),
  KEY `city` (`city`),
  CONSTRAINT `restaurants_ibfk_1` FOREIGN KEY (`country`) REFERENCES `country` (`country`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `restaurants_ibfk_2` FOREIGN KEY (`city`) REFERENCES `city` (`city`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `restaurants`
--

LOCK TABLES `restaurants` WRITE;
/*!40000 ALTER TABLE `restaurants` DISABLE KEYS */;
INSERT INTO `restaurants` VALUES ('R01','Nafees Restaurant',1,1,'Apollo Avenue, 30-B, Greater Kailash Road, New Palasia','9039090005','rj.43@rediffmail.com','nafees123',100),('R02','Sayaji Restaurant',1,1,'H/1 , Scheme No.54, Vijay Nagar','7389910949','sayajirest@gmail.com','sayaji123',150),('R03','Enrise Restaurant',1,1,'27/1, 27/2, VILLAGE PIGDAMBAR, RAU, TEHSIL MHOW, Mumbai - Agra National Hwy','7314706666','enriserest@gmail.com','enrise123',120),('R04','Shreemaya Restaurant',1,1,'12, RNT Marg, South Tukoganj','7314234888','shreemayarest@gmail.com','shreemaya123',70),('R05','Daagla Restaurant',1,1,'Hotel Thamla Haveli, Hanuman Ghat, Outside Chandpole','9982988899','daaglarest@gmail.com','daagla123',50),('R06','Savya Rasa',1,1,'Gera Serenity Building, CTS No. 15, near Starbucks Cafe, Koregaon Park','9130095522','savyarasa@gmail.com','savya123',60),('R07','Barbeque Nation',1,1,'1st Floor, Golden Square, Parle Point Flyover, near Sargam Shopping Center, Athwa','7849006060','barbntn@gmail.com','barbntn123',200),('R08','Starbucks Cafe',1,1,'Gera Serenity Building, CTS No. 15, near Starbucks Cafe, Koregaon Park','9130095542','starbucks@gmail.com','star123',90),('R09','Central Perk',3,7,'105 Cedarhurst Ave, Cedarhurst, NY 11516','1516374640','centralperk@gmail.com','centralperk123',250),('R10','La Patsa Lb',7,5,'Calle Casanova 94, 08011','3493031231','lappatsa@gmail.com','lapatsa123',150),('R11','Vrindavan',1,1,'19/6, Janjeerwala Square, New Palasia','7314009123','vrinrest@gmail.com','vrin123',70),('R12','The Monroe',1,1,' Gold Stone Building, 3/5, near 56 Shops, New Palasia','7314002883','themonroe@gmail.com','mon123',100),('R13','Little Monk',1,1,' Nirvana Hotel & Resort, MR 10, Near Over Bridge, Super Corridor Rd','7440448003','littlrmonk@gmail.com','lmonk123',90),('R14','Shree Gurukripa',1,1,' Kushabhau Thakre Marg, Opposite Bombay Hospital','7314222202','grurkripa@gmail.com','gk123',60),('R15','Apna Sweets',1,1,'A B Road Vijay Nagar','7312557310','apnasweets@gmail.com','ana123',50),('R16','Pishori Dhaba',1,1,' 3-A, Eastern Ring Rd, Nanak Nagar','7314964461','pishoridhaba@gmail.com','pishdh123',50),('R17','Bawarchi Restaurant',1,19,'Plot No. 44, RTC Cross Rd, Opposite Sandhya Theatre, Jawahar Nagar','4027634490','bawarchi@gmail.com','bawar123',60),('R18','Okra',1,19,'Hyderabad Marriott Hotel & Convention Centre, Tank Bund Road','9666412009','okra@gmail.com','okra123',80),('R19','Tatva',1,19,'1215/A, Rd Number 36, Jubilee Hills','7995028026','tatva@gmail.com','tatva123',75),('R20','Hard Rock Cafe',1,19,' Gvk One, Rd Number 1, Balapur Basthi, Banjara Hills','9820267989','hardrock@gmail.com','rhc123',60),('R21','The Venue',3,8,'3470 Wilshire Blvd b1','2132211251','thevenue@gmail.com','ven123',70),('R22','Craig\'s',3,8,'8826 Melrose Ave, West Hollywood','3102761900','craig@gmail.com','craig123',130);
/*!40000 ALTER TABLE `restaurants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reward_link`
--

DROP TABLE IF EXISTS `reward_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reward_link` (
  `reward_id` int(10) DEFAULT NULL,
  `user_id` varchar(10) DEFAULT NULL,
  UNIQUE KEY `rewards` (`reward_id`,`user_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `reward_link_ibfk_1` FOREIGN KEY (`reward_id`) REFERENCES `rewards` (`reward_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `reward_link_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reward_link`
--

LOCK TABLES `reward_link` WRITE;
/*!40000 ALTER TABLE `reward_link` DISABLE KEYS */;
INSERT INTO `reward_link` VALUES (1,'raja102885'),(2,'miko109921'),(2,'Saqw123694'),(3,'kajh109594'),(3,'kebh998864'),(4,'kajh109594'),(5,'miko109921'),(6,'raja102885');
/*!40000 ALTER TABLE `reward_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rewards`
--

DROP TABLE IF EXISTS `rewards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rewards` (
  `reward_id` int(10) NOT NULL AUTO_INCREMENT,
  `reward_details` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`reward_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rewards`
--

LOCK TABLES `rewards` WRITE;
/*!40000 ALTER TABLE `rewards` DISABLE KEYS */;
INSERT INTO `rewards` VALUES (1,'Use AMAZE120 To Get Rs.100/- Off On Table Booking. Valid Till Dec 31,2020.'),(2,'Congratulations On Receiving 10% Cashback. Redeem Using CASHB100. Valid For 15 Days.'),(3,'Rs.1500/- Welcome Gift Card. Use Code GCARD22. Valid For 5 Days'),(4,'Rs.550 Instant Discount On Your Bill. Apply Code DISC98. Valid Till January 7,2021.'),(5,'100% Off On The Next Booking. Use Code BOOK100. Valid For 10 Days.'),(6,'1+1 At Top Restaurants For The Next 3 Months. Apply Code DINE33');
/*!40000 ALTER TABLE `rewards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `user_id` varchar(10) NOT NULL,
  `first_name` varchar(20) DEFAULT NULL,
  `last_name` varchar(20) DEFAULT NULL,
  `mobile` varchar(10) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `pswrd` varchar(26) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `account` (`first_name`,`last_name`,`mobile`,`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES ('as981po646','asdh','poiu','9817263484','hlucifer44@gmail.com','98765as981po646'),('kajh109594','kanak','jhawar','1092387456','kj@jk.com','12345kajh109594'),('kebh998864','keshav','bhutada','9981456555','bhutadakeshav22@gmail.com','keshav22kebh998864'),('miko109921','mitali','koibhi','1092837465','hqamruddin786@rediffmail.com','12345miko109921'),('raja102885','raj','jar','1023456789','rj.43@rediffmail.com','98765raja102885'),('Saqw123694','Sakina','qwerty','1234567890','hlucifer44@gmail.com','12345Saqw123694');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-12-27 18:54:01
