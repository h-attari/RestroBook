from django.shortcuts import render,redirect
from django.http import HttpResponse
import mysql.connector as mysql
import smtplib
from email.mime.text import MIMEText
# Create your views here.

def login(req):
	return redirect('/admins/query')

def query(req):
	conn = mysql.connect(host="localhost",user="root",password="root",database="RestroBook")
	cr = conn.cursor()
	admins = []
	quer = []
	if req.session.has_key('id'):
		admins.append(req.session['id'])
		admins.append(req.session['name'])
		qu = "select * from queries"
		cr.execute(qu)
		rec = cr.fetchall()
		i = 1
		for x in rec:
			temp = []
			if x[5] == None and x[6] == None:
				temp.append(i)
				temp.append(x[1])
				temp.append(x[2])
				temp.append(x[3])
				temp.append(x[4])
			elif x[5] != None:
				qu = "select first_name, last_name, mobile, email from users where user_id=%s"
				v = (x[5],)
				cr.execute(qu,v)
				urec = cr.fetchone()
				temp.append(i)
				temp.append(urec[0] + ' ' + urec[1])
				temp.append(urec[2])
				temp.append(urec[3])
				temp.append(x[4])
			quer.append(temp)
			i += 1
	conn.close()
	return render(req,'query.html', {'quer':quer, 'admin':admins})

def bookings(req):
	admins = []
	if req.session.has_key('id'):
		admins.append(req.session['id'])
		admins.append(req.session['name'])
	bookid = req.GET.get("bid")
	conn = mysql.connect(host="localhost",user="root",password="root",database="RestroBook")
	cr = conn.cursor()
	if bookid == None:
		qu = "select * from booking order by booking_date desc"
		cr.execute(qu)
		rec = cr.fetchall()
	else:
		qu = "select * from booking where book_id=%s"
		v = (bookid,)
		cr.execute(qu,v)
		rec = cr.fetchall()
		if rec == []:
			qu = "select * from booking where user_id=%s order by booking_date desc"
			v = (bookid,)
			cr.execute(qu,v)
			rec = cr.fetchall()
	b_data = []
	for x in rec:
		qu = "select * from users where user_id=%s"
		v = (x[5],)
		cr.execute(qu,v)
		user = cr.fetchone()
		temp = list(x)
		temp[5] = (user[1].capitalize(),user[2].capitalize(),user[0],user[3],user[4])
		qu = "select * from restaurants where rest_id=%s"
		v = (x[6],)
		cr.execute(qu,v)
		rest = cr.fetchone()
		qu = "select city_name from city where city=%s"
		v = (rest[3],)
		cr.execute(qu,v)
		city = cr.fetchone()
		qu = "select country_name from country where country=%s"
		v = (rest[2],)
		cr.execute(qu,v)
		cntry = cr.fetchone()
		temp[6] = (rest[1],rest[0],rest[5],rest[6],rest[4],city[0],cntry[0])
		if temp[8] == "debit":
			temp[8] = "Debit Card"
		elif temp[8] == "credit":
			temp[8] = "Credit Card"
		else:
			temp[8] = "Net Banking"
		b_data.append(temp)
	conn.close()
	return render(req,'bookings.html',{"admin":admins,"rec":b_data,"bookid":bookid})

def reply(req):
	conn = mysql.connect(host="localhost",user="root",password="root",database="RestroBook")
	cr = conn.cursor()
	qreply = req.POST.get("qreply")
	data = req.POST.get("reply").split(',')
	qid = data[0][1:]
	name = data[1][2:-1]
	mail = data[3][2:-1]
	query = data[-1][2:-2]
	server = smtplib.SMTP('smtp.gmail.com', 587)
	html="""
	<html>
		<body>
			<div>
				<p style="font-size:18px;">
					Welcome <i>{0}</i>!
				</p>
				<br><br>
				<p style="font-size:16px;">
					The answer to your query, <i>{1}</i> is,
					<br><strong>{2}</strong>
				</p>
			</div>
		</body>
	</html>""".format(name,query,qreply)
	msg=MIMEText(html, 'html')
	server.starttls()
	server.login("hlucifer44@gmail.com", "1060543987")
	server.sendmail("hlucifer44@gmail.com", mail, msg.as_string())
	server.quit()
	qu = "delete from queries where query_id=%s"
	v = (qid,)
	cr.execute(qu,v)
	conn.commit()
	conn.close()
	return redirect('/admins/query')