from django.shortcuts import render,redirect
from django.http import HttpResponse
import mysql.connector as mysql
# Create your views here.

def login(req):
	return redirect('/admins/query')

def query(req):
	conn = mysql.connect(host="localhost",user="root",password="root",database="RestroBook")
	cr = conn.cursor()
	qu = "select * from queries"
	cr.execute(qu)
	rec = cr.fetchall()
	quer = []
	i = 1
	for x in rec:
		temp = []
		if x[5] == None and x[6] == None:
			temp.append(i)
			temp.append(x[1])
			temp.append(x[2])
			temp.append(x[3])
			temp.append(x[4])
		elif x[5] != None:
			qu = "select first_name, last_name, mobile, email from users where user_id=%s"
			v = (x[5],)
			cr.execute(qu,v)
			urec = cr.fetchone()
			temp.append(i)
			temp.append(urec[0] + urec[1])
			temp.append(urec[2])
			temp.append(urec[3])
			temp.append(x[4])
		quer.append(temp)
		i += 1
	conn.close()
	return render(req,'query.html', {'quer':quer})

def bookings(req):
	return render(req,'bookings.html')