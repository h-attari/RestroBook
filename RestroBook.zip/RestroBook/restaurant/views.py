from django.shortcuts import render, redirect
import mysql.connector as mysql
import smtplib
from email.mime.text import MIMEText
from RestroBook.static.menu import menu as menus
import json
import os

def creddata(req):
	rest = []
	if req.session.has_key('id'):
		rest.append(req.session['id'])
		rest.append(req.session['name'])
	return rest

def login(req):
	return redirect('/restaurant/dashboard')

def dashboard(req):
	rest = creddata(req)
	conn = mysql.connect(host="localhost",user="root",password="root",database="RestroBook")
	cr = conn.cursor()
	qu = "select book_id,guests,date,time from booking where rest_id=%s and pending=%s"
	v = (rest[0],1)
	cr.execute(qu,v)
	dash = cr.fetchall()
	conn.close()
	return render(req,'dashboard.html',{"rest":rest,"dash":dash})

def mails(req,tsk,user,mail,guest,date,time):
	if tsk == "reject":
		msg = "Rejected"
	else:
		msg = "Accepted"
	rest = req.session["name"]
	server = smtplib.SMTP('smtp.gmail.com', 587)
	html="""
	<html>
		<body>
			<div>
				<p style="font-size:18px;">
					Welcome <i>{0}</i>!
				</p>
				<br><br>
				<p style="font-size:16px;">
					You'r request for table booking in <strong>{1}</strong> for <strong>{2}</strong> people for Date: <strong>{3}</strong> &amp; <strong>{4}</strong> has been <strong><i>{5}</i></strong>.
				</p>
			</div>
		</body>
	</html>""".format(user,rest,guest,date,time,msg)
	msg=MIMEText(html, 'html')
	server.starttls()
	server.login("hlucifer44@gmail.com", "1060543987")
	server.sendmail("hlucifer44@gmail.com", mail, msg.as_string())
	server.quit()

def dashtask(req):
	rest = creddata(req)
	conn = mysql.connect(host="localhost",user="root",password="root",database="RestroBook")
	cr = conn.cursor()
	book_id = req.POST.get("bookid")
	task = req.POST.get("task")
	qu = "select user_id,guests,date,time from booking where book_id=%s"
	v = (book_id,)
	cr.execute(qu,v)
	rec = cr.fetchone()
	qu = "select first_name,last_name,email from users where user_id=%s"
	v = (rec[0],)
	cr.execute(qu,v)
	user = cr.fetchone()
	name = user[0].capitalize() + user[1].capitalize()
	if task == "reject":
		qu = "delete from booking where book_id=%s"
		v = (book_id,)
		mails(req,task,name,user[2],rec[1],rec[2],rec[3])
	else:
		qu = "update booking set pending=%s where book_id=%s"
		v = (0,book_id)
		mails(req,task,name,user[2],rec[1],rec[2],rec[3])
	cr.execute(qu,v)
	conn.commit()
	conn.close()
	return redirect('/restaurant/dashboard')

def menu(req):
	rest = creddata(req)
	# x ="python ./RestroBook/static/menu/"+rest[0]+".py"
	# os.system(x)
	m = menus.menu(rest[0])
	return render(req,'menu.html',{"rest":rest,"menu":m})

def record(req):
	rest = creddata(req)
	conn = mysql.connect(host="localhost",user="root",password="root",database="RestroBook")
	cr = conn.cursor()
	qu = "select * from booking where rest_id=%s and pending=%s"
	v = (rest[0],0)
	cr.execute(qu,v)
	rec = cr.fetchall()
	data = []
	for x in rec:
		qu = "select * from users where user_id=%s"
		v = (x[5],)
		cr.execute(qu,v)
		user = cr.fetchone()
		temp = list(x)
		temp[5] = (user[0],user[1].capitalize(),user[2].capitalize(),user[3],user[4])
		data.append(temp)
	conn.close()
	return render(req,'record.html',{"rest":rest,"rec":data})