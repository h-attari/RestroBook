from django.shortcuts import render

# Create your views here.
def dashboard(req):
	return render(req,"dashboard.html")

def menu(req):
	return render(req,"menu.html")

def record(req):
	return render(req,"record.html")