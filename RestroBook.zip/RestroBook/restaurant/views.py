from django.shortcuts import render, redirect
import mysql.connector as mysql

def creddata(req):
	rest = []
	if req.session.has_key('id'):
		rest.append(req.session['id'])
		rest.append(req.session['name'])
	return rest

def login(req):
	return redirect('/restaurant/dashboard')

def dashboard(req):
	rest = creddata(req)
	return render(req,'dashboard.html',{"rest":rest})

def menu(req):
	rest = creddata(req)
	return render(req,'menu.html',{"rest":rest})

def record(req):
	rest = creddata(req)
	return render(req,'record.html',{"rest":rest})