import json
r18={}
r18['Appetizers']={}
r18['Appetizers']['Western']={'Smoked Salmon, Sour Dough Bread, Shaved Fennel Egg Yolk and Citrus Salad':675,'Prawns Straight Ups with Aioli':675,'Mediterranean Slow Poached Chicken Salad':599,'Caesar Salad':549,'Quinoa Salad':499}
r18['Appetizers']['Asian']={'Sichuan Fried Fish':599,'Indonesian Chicken Satay, Peanut Sauce':599,'Veg Spring Roll':499,'Crispy Corn Niblets, Sriracha, Chilli, Lemon':499}
r18['Appetizers']['Indian']={'Sarson Mahi Tikka':625,'Kacche Gosht ki Seekh Kebab':625,'Nawabi Paneer Tikka':499,'Hare Matar ki Tawa Tikki':499}
r18['Appetizers']['Soups']={'Clear Veg and Noodle Soup':325,'Hot and Sour Soup':325,'Slow Roasted Tomato and Sweet Basil Soup':325,'Cream of Green Pea and Mint Soup':325}
r18['Appetizers']['Sandwiches']={'Marriot Club Sandwich':599,'Smoked Salmon Bagel Sandwich':599,'Marriot Club Veg Sandwich':550,'Mumbai Masala Sandwich':550}
r18['Pizza']={}
r18['Pizza']['']={'Pizza Calabrese':575,'Pizza Indiana':550,'Pizza del Casa':550,'Pizza Margherita':550,'Pizza Quattro Formaggie':550}
r18['Main Course']={}
r18['Main Course']['Western']={'Slow Cooked New Zealand Lamb Shank':1325,'Pan Seared Salmon Steak':1125,'Oven Roasted Chicken Breast':725,'Soft Herb Polenta':599}
r18['Main Course']['Asian']={'Nasi Goreng':725,'Kung Pao Chicken':625,'Curries':625}
r18['Main Course']['Indian']={'Homemade Fish Curry':699,'Gosht Khada Masala':675,'Mung Mukhanwala':650,'Paneer':550,'Subz Nizami Korma':525,'Aloo Gobi Adraki':475,'Kadhai Subz':475}
r18['Rice']={}
r18['Rice']['']={'Dum Murgh Biryani':699,'Dum Subz Biryani':599,'Khichadi':399,'Chawal ke Nazrane':325,'Steamed Basmati Rice':250}
r18['Desserts']={}
r18['Desserts']['']={'Sundae':299,'Chocolate Brownie':225,'Seasonal Fresh Fruit Platter':199}
f=open('./RestroBook/static/menu/R.py','w+')
f.truncate(0)
f.write(json.dumps(r18))
f.close()