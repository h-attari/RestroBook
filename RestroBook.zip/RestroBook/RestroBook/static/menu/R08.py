import json
r8={}
r8['drinks']={}
r8['drinks']['Hot Coffee']={'Caffe Americano':245,'Blonde Roast':245,'Caffe Misto':255,'Dark Roast Coffee':300,'Pike Placer Roast':345,'Decaf Pike Placer Roast':375,'Cappuccino':245,'Espresso':245,'Espresso Con Panna':299,'Pumpkin Spice Latte':315,'Honey Oatmilk Latte':345,'Caffe Latte':315,'Cinnamon Latte':315,'Blonde Vanilla Latte':345,'Salted Caramel Mocha':345,'Caffe Mocha':345}
r8['drinks']['Hot Tea']={'Chai Tea':215,'Chai Latte':245,'Earl Grey':299,'London Fog Tea Latte':315,'English Breakfast Tea':339,'English Breakfast Tea Latte':359,'Matcha Green Tea Latte':249,'Honey Citrus Mint Tea':249,'Jade Citrus Mint Brewed Tea':275,'Mint Mystery':215,'Peach Tranquility':245}
r8['drinks']['Cold Coffee']={'Pumpkin Cream Cold Brew':445,'Cold Brew with Cinnamon Almond Milk Foam':445,'Cold Brew with Dark Cocca Almond Milk Foam':445,'Cold Brew with Cinnamon Oatmilk Foam':499,'Pumpkin Cream Nitro Cold Brew':549,'Nitro Cold Brew with Cinnamon Almond Milk Foam':549,'Nitro Cold Brew with Dark Cocca Almond Milk Foam':549,'Nitro Cold Brew':499,'Iced Caffe':449,'Iced Espresso':499,'Iced Latte':499}
r8['drinks']['Iced Tea']={'Teavana Mango Black Tea':349,'Teavana Sparkling Blood Orange Mango White Tea':349,'Iced Guava Black Tea':399,'Guava Black Iced Tea Lemonade':419,'Iced Black Tea':339,'Iced Black Tea Lemonade':350,'Iced Peach Green Tea':350,'Iced Peach Green Tea Lemonade':350,'Iced Green Tea':339,'Iced Green Tea Lemonade':349}
r8['food']={}
r8['food']['Bakery']={'Plain Bagel':215,'Blueberry Bagel':235,'Cheese Onion & Garlic Bagel':235,'Cinnamon Raisin Bagel':235,'Fox Cake Pop':175,'Unicorn Cake Pop':175,'Blueberry Oat Cake':175,'Birthday Cake Pop':175,'Confetti Sugar Cookie':175,'Chocolate Chip Cookie':175,'Double Chocolate Chunk Brownie':235,'Almond Croissant':275,'Butter Croissant':275,'Cheese Danish':275,'Marshmallow Bar':375}
r8['food']['Lunch']={'Crispy Grilled Cheese Sandwich':399,'Ham and Swiss Panini':399,'Turkey and Basil Pesto':399,'Chicken Caprese':399,'Grilled Chicken and Humus Protein Box':475,'Eggs and Cheese Protein Box':375,'Peanut Butter and Jam Protein Box':375,'Cheese and Fruit Protein Box':375,'Chicken and Quinoa Protein Bowl with Black Beans and Greens':575,'Kale and Farro Salad':275,'Herbal Chicken Side':349}
r8['food']['Snacks and Sweets']={'Dipped Madeleines':245,'Madeleines':215,'Vanilla Biscotti with Almond':245,'Shortbread Cookies':225,'Salted Almond Chocolate Bites':215,'Chocolate Covered Espresso Beans':215,'Perfect Bar-Dark Chocolate Chip Peanut Butter':125,'Peanut Butter Bar':125,'Urban Trail Bar':125,'Almond Coconut Cashew Chai':125,'Apple Blueberry Bar':125,'Avocado Spread':99}
r8['food']['Yogurt and Custard']={'Berry Trio Parfat':245,'Strawberry Overnight Grains':245,'Siggi Yogurt Cup':245}
f=open('./RestroBook/static/menu/R.py','w+')
f.truncate(0)
f.write(json.dumps(r8))
f.close()