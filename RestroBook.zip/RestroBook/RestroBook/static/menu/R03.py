import json
r3={}
r3['breakfast']={}
r3['breakfast']['']={'English Breakfast':240,'Continental Breakfast':240,'India Breakfast':240,'Fitness Breakfast':215,'Fresh Fruit Platter':165,'French Toast':160,'Farm Fresh Boiled Eggs':125}
r3['starter']={}
r3['starter']['']={'French Fries':99}
r3['starter']['Pakora']={'Mixed Veg Pakora':199,'Paneer Pakora':249,'Egg Pakora':249}
r3['starter']['Soup']={'Tomato Dhaniya Shorba':149,'Veg Spicy Noodle Broth':149,'Veg Clear Soup':149,'Veg Manchow Soup':149,'Veg Hot and Sour Soup':149,'Veg Sweet Corn Soup':149,'Chicken Clear Soup':175,'Chicken Manchow Soup':175,'Chicken Hot and Sour Soup':175,' Chicken Sweet Corn Soup':175}
r3['starter']['Veg']={'Paneer Nasheman Tikka':299,'Dahi Kebab':249,'Paneer Poshida':299,'Hara Bhara Kebab':249,'Paneer Tikka':299,'Tandoori Subz ka Mela':299}
r3['starter']['Non Veg']={'Thai Basil Chicken':349,'Murgh Kali Mirch Tikka':349,'Chicken 65':370,'Bhatti ka Murgh':549,'Murgh Saunfiya Tikka':349,'Murgh Kasuri Tikka':349}
r3['sandwiches']={'Veg':{'Enrise Club Sandwice':249,'Classic Tomato and Cucumber Sandwich':199},'Non Veg':{'Enrise Club Sandwich':299,'Creamy Chicken Sandwich':249}}
r3['main course']={}
r3['main course']['Veg']={'Paneer Makhani':349,'Nargisi Kofta Curry':349,'Birbal ki Handi':349,'Jeera Aloo':249,'Bhindi Do Pyaza':249,'Saag-e-Noor Mahal':349,'Leo Musallam':349}
r3['main course']['Non Veg']={'Murgh Tikka':399,'Bhuna Mutton':449,'Fish Tikka Masala':399,'Egg Masala':249,'Murgh Pashtun':399,'Bengali Fish Curry':399}
r3['roti']={}
r3['roti']['']={'Tandoori Roti':25,'Roomali Roti':30,'Butter Naan':50,'Chilli Garlic Naan':55,'Tawa Roti':20,'Aloo Kulcha':80,'Paneer Kulcha':120,'Keema Kulcha':170}
r3['continental']={}
r3['continental']['Veg']={'Baked Veg':299,'Spaghetti Napolitana':349,'Penne Pasta':349,'Macroni Pasta':349,'Farfalle Pasta':349}
r3['continental']['Non Veg']={'Fish Fry':349,'Fsih Finger':349,'Spaghetti Bolognese':399,'Cajun Spiced Prawns':399}
r3['sides']={}
r3['sides']['Salads']={'Green Salad':149,'Sprout Salad':149,'Fresh Fruit Chaat':199,'Caesar Salad Veg/Non Veg':249,'Russian Salad Veg/Non Veg':199,'Peanut Chaat Salad':149}
r3['sides']['Papad']={'Roasted/Fried Papad':30,'Roasted/Fried Masala Papad':49}
r3['sides']['Raita']={'Plain Curd':75,'Boondi Raita':99,'Pineapple Raita':99,'Mix Veg Raita':99}
r3['rice']={}
r3['rice']['Veg']={'Plain Rice':120,'Jeera Rice':160,'Steamed Rice':199,'Handi Biryani Veg':249}
r3['rice']['Non Veg']={'Dum Biryani Chicken':349,'Dum Biryani Mutton':399,'Dum Biryani Egg':240,'Schezwan Chicken Fried Rice':299}
r3['desserts']={}
r3['desserts']['']={'Rasmalai':149,'Gulab Jamun':125,'Phirni':125,'Shahi Tukda':125,'Ice Cream':99}
r3['beverages']={}
r3['beverages']['']={'Canned Fruit Juice':135,'Lassi Sweet/Salted':135,'Cold Coffee':125,'Milk Shake':135,'Butter Milk Plain/Masala':130}
f=open('./RestroBook/static/menu/R.py','w+')
f.truncate(0)
f.write(json.dumps(r3))
f.close()