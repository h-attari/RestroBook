import json
r16={}
r16['starter']={}
r16['starter']['Soup']={'Veg':{'Veg Clear Soup':60,'Sweet Corn Soup':70,'Cream of Tomato':70,'Cream of Spinach':70,'Lemon Corriander Soup':70,'Veg Manchow':70,'Hot and Sour':70},'Non Veg':{'Chicken Sweet Corn':90,'Chicken Hot and Sour':90,'Chicken Manchow':90,'Cream of Chicken':70,'Chicken Clear Soup':80 }}
r16['starter']['Snacks']={'Paneer Pakoda':130,'Kaju Fry':130,'Veg Pakoda':90,'Green Peas Roast':90,'Kalali Pakoda':90,'Finger Chips':70,'Aloo Chaat':60}
r16['starter']['Kebab']={'Veg':{'Veg Platter':300,'Paneer Tikka':150,'Paneer Pahadi Tikka':160,'Paneer Achaari Tikka':150,'Boti Paneer':160,'Boti Mushroom':160,'Mushroom Tikka':150},'Non Veg':{'Tandoori Chicken Full/Half':(200,140),'Chicken Amritsari Full/Half':(280,150),'Grill Chicken Full/Half':(300,200),'Boti Chicken Kebab':210,'Murgh Malai Tikka':180,'Tangdi Gulmohar Kebab':200,'Chicken Seekh Kebab':190,'Mutton Seelh Kebab':190}}
r16['starter']['Egg']={'Boiled Egg':40,'Fried Egg':50,'Egg Pakoda':120,'Omlete':60,'Masala Omlete':70,'Cheese Omlete':90}
r16['starter']['Chinese']={'Veg':{'Paneer Finger':150,'Paneer Lollipop':150,'Paneer Choti Boti':170,'Veg Manchurian':120,'Spring Roll':120,'Gold Corn':160,'Veg Kothey':130,'Crispy Corn':130,'Chana Chilly':130,'Potato 65':120},'Non Veg':{'Chilly Chicken Full/Half':(280,180),'Chicken 65':(300,200),'Chicken Manchurian':(300,200),'Chicken Crispy Spe':(220,180),'Fish Finger':200,'Prawns Chilly':350,'Chicken Fried Rice':150,'Prawns Fried Rice':260}}
r16['main course']={}
r16['main course']['Veg']={'Paneer Tikka Masala':180,'Paneer Butter Masala':140,'Paneer Kandhari':140,'Paneer Mutter':130,'Paneer Kadhai':140,'Paneer Handi':140,'Paneer Pasanda':160,'Shahi Paneer':140,'Kaju Curry':170,'Corn Palak':120,'Aloo Matar':80}
r16['main course']['Non Veg']={'Butter Chicken':370,'Chicken Kadhai':370,'Chicken Handi':370,'Tawa Chicken':370,'Chicken Curry':370,'Chicken Patiyala':380,'Mutton Mughlai':200,'Mutton Curry':200,'Mutton Handi':200,'Mutton Do Pyaaza':200,'Fish Curry':200,'Fish Masala':210,'Egg Curry':120}
r16['main course']['Dal']={'Dal Fry':80,'Dal Tadka':90,'Dal Jeera':80,'Dal Makhani':100}
r16['roti']={'Tandoori Roti':10,'Roomali Roti':10,'Butter Naan':25,'Chilli Garlic Naan':35,'Missi Roti':12,'Stuffed Kulcha':20,'Paneer Kulcha':30,'Keema Paratha':50,'Stuffed Paratha':30}
r16['Rice']={'Gravy Rice':120,'Masala Rice':120,'Chicken Biryani':170,'Mutton Biryani':180,'Fish Biryani':180,'Egg Biryani':140,'PlaiN Rice':70,'Jeera Fried Rice':80,'Onion Rice':80,'Veg Biryani':130}
r16['sides']={}
r16['sides']['Salad']={'Green Salad':40,'Kachumber Salad':50,'Dahi Kachumber':40,'Punjabi Salad':50,'Russian Salad':20}
r16['sides']['Raita']={'Veg Raita':80,'Boondi Raita':80,'Aloo Raita':80,'Onion Raita':70,'Pineapple Raita':90,'Fruit Raita':90,'Plain Curd':50}
r16['sides']['Papad']={'Masala Papad Fry/Dry':25,'Papad Fry/Dry':20}
r16['beverages']={}
r16['beverages']['Cocktail']={'Blood Marry':200,'Whisky Sour':200,'Screw Driver':200,'Blue Lagoon':200,'Summer Breeze':200,'Salty Dog':200,'Rum Collins':20,'Pinacolada':200}
r16['beverages']['Mocktail']={'Casino Royal':60,'Blue Angel':60,'Pink Panther':60,'Green Temptation':60,'Big Smile':60,'Virgin Mojito':60,'Colabita':60,'Blose on Ice':60,'Fruit Punch':100,'Red Wings':90,'On The Beach':100}
r16['beverages']['Cold']={'Red Bull':130,'Diet Coke':40,'Lime Soda':40,'Lime Water':30,'Lassi':30,'Butter Milk':30,'Jal Jeera':30}
f=open('./RestroBook/static/menu/R.py','w+')
f.truncate(0)
f.write(json.dumps(r16))
f.close()