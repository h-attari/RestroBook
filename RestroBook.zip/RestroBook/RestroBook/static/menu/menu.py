import json
import os

def listing(dit):
	l=[x.title() for x in dit.keys()]
	print(l)
	for k,v in dit.items():
		if isinstance(v,dict) and v.keys() != None:
			listing(v)

def menu(index):
	ind=index+".py"
	f=open(ind,"r")
	fr=f.read()
	dit=json.loads(fr)
	listing(dit)

index=input()
x ="python "+index+".py"
os.system(x)
menu('R')