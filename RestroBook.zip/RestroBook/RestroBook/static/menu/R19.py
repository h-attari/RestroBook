import json
r19={}
r19['Starters']={}
r19['Starters']['Soups']={'Tomato and Basil Soup':220,'Vichyssoise':220,'Mushroom Barley Broth':220,'Carrot Orange and Ginger':220,'Florentine':220,'PHO':220,'Sweet Corn':220}
r19['Starters']['Tandoor']={'Kamalkakdi ke Galouti':430,'Smoked Pesto Paneer Tikka':430,'Sounfiyana Malai Paneer Tikka':430,'Dahi ke Kebab':380,'Soya Shami Kebab':380}
r19['Starters']['Chinese']={'Manchurian':380,'Spring Rolls':380,'Schezuan':380,'Chilli':380,'Crackling Spinach':380,'Jamur Oelek':380,'Kung Pao Lotus Stem':380,'Sweet and Spicy Water Chestnut':380}
r19['Starters']['Continental']={'Jalapeno Poppers':380,'Quesadilla':380,'Gondola':380,'Falafel and Humus':380,'Lebanese Mezze Platter':380,'Lotus Stem Kibbeh':380}
r19['Main Course']={}
r19['Main Course']['Continental']={'Lasagne':480,'Drums of Heaven':480,'Risotto Cream':480,'Risotto Paprika':480,'Wild Mushroom Risotto':480,'Risotto Verde':480,'Cottage Cheese Enchiladas':480}
r19['Main Course']['Indian']={'Paneer Tikka Masala':450,'Paneer Khurchan':450,'Paneer Butter Masala':450,'Methi Chaman Bahaar':450,'Palak Paneer':450,'Dum ka Paneer':450,'Kadai Paneer':450,'Tarkari Koftey':450,'Kamalkakdi Lababdar':450,'Awadhi Tawa Sabzi':450,'Subz ki Shaan':450}
r19['Main Course']['Chinese']={'Thai Curry':380,'Diced Veg in Shanghai Sauce':380,'Five Treasure Hunan':380,'Mapo Doufu':380,'Mix Veg Manchurian Gravy':380,'Exotic Veg Schezuan Style':380}
r19['Pasta']={'Penne':480,'Spaghetti':480,'Fettuccine':480,'Fusilli':480,'Cheese Tortellini':480}
r19['Sizzler']={'Mexican Sizzler':480,'Veg Steak Sizzler':480,'Tropical Sizzler':480,'Mangolian Sizzler':480,'Jain Sizzler':480}
r19['Pizza']={'Sierra Nevada':500,'Al Fungi':500,'Quattro Formaggie':500,'Margherita':450,'Tandoori Paneer Tikka':450,'Mediterranean':450}
r19['Ricd and Biryani']={'Veg Biryani':450,'Cashew Nut Pulao':400,'Veg Pulao':350,'Olive Rice':350,'Sambar Rice':300,'Jeera Rice':250,'Curd Rice':200}
r19['Sides']={}
r19['Sides']['Salads']={'Caesar Salad':300,'Beetroot and Orange Salad':300,'Sicila':300,'Dill Cucumbre Yoghurt':300,'Roasted Potato and Raisin Salad':300,'Poached Apple and Pear Salad':300,'Green Salad':225}
r19['Sides']['Continental']={'Chilli Cheese Garlic Bread':250,'Garlic Bread':200,'Wedges':200,'Fries':160}
r19['Sides']['Indian']={'Cheese Masala Papad':120,'Masala Papad':100,'Papad':80,'Raita':80}
r19['Desserts']={'Paan Tantra':350,'Momento D Fusion':350,'Chocolate Mousse':350,'Banoffee':350,'Tiramisu':350,'Tender Coconut Panacotta':350,'Rasmalai Panacotta':350,'Hazelnut Gateaux':350}
f=open('R.py','w+')
f.truncate(0)
f.write(json.dumps(r19))
f.close()