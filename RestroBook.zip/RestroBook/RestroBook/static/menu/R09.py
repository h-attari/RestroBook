import json
r9={}
r9['breakfast']={'Eggs Amy Style':1001,'Spanish Omelet':1109,'Huevas Rancheros':1182,'Egg Florentine':1109,'Oatmeal':556,'Waffles':853}
r9['appetizers']={'Blooming Onion':882,'Zucchini Sticks':886,'Mozzarella Sticks':960,'Quesadillas':1094,'Mozzarella Basket':1183}
r9['soups']={'French Onion Soup':664,'Cream Soup of the Day':626,'Soup of the Day':589}
r9['salads']={'Bacchini Cheese Salad':1257,'Teriyaki Salmon Salad':1409,'Tuna Nicoise Salad':1443,'Grilled Tuna Cream Salad':1443}
r9['pizza']={'Classic Pizza':1109,'Pesto Pizza':1182,'Pizza Margarita':1295,'Penne Vodka Pizza':1257,'Veg Pizza':1183,'Portabella Pizza':1183,'Whole Wheat Salad Pizza':1257}
r9['fish']={'Almond Crushed Salmon':2296,'Teriyaki Salmon':2147,'Honey Mustard Glazed Salmon':2147,'Salmon Cream Dill and Asparagus':2225,'Cajun Salmon':2221,'Grilled Salmon':2147,'Cajun Tuna':2296,'Spicy Crushed Sale':20173}
r9['burger']={'Veggie Burger':1109,'Chilli Veggie Burger':1183,'Quinoa Burger':1183}
r9['pasta']={'Penne Marinara':1331,'Mac and Cheese':1331,'Baked Ziti':1331,'Penne Tomato Basil':1331,'Baked Cheese Penne':1331}
r9['paninis']={'Fresh Mozzarella Panini':1183,'Avocado Panini':1183,'Tuna Melt Panini':1183,'Grilled Cheese Panini':1183}
r9['wraps']={'Grilled Salmon Wrap':1480,'Falafal Wrap':1109,'Avocado Wrap':1109,'Tuna Salad Wrap':1109}
r9['drinks']={}
r9['drinks']['Hot Drinks']={'Coffee':148,'Latte':296,'Cappuccino':296,'Espresso':200,'White Chocolate Mocha':333,'Mochaccina':333,'Chai Tea Latte':296,'Apple Cider':204,'Carmelina':333,'Hot Chocolate':204}
r9['drinks']['Iced Drinks']={'Iced Coffee':185,'Iced Cappuccino':278,'Iced Latte':278,'Ice Mochaccina':315}
f=open('./RestroBook/static/menu/R.py','w+')
f.truncate(0)
f.write(json.dumps(r9))
f.close()