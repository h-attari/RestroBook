import json
r20={}
r20['Beverages']={}
r20['Beverages']['Keepers']={'Triple Platinum Margarita':689,'Fruitapalooza':699,'Ultimate Long Island Iced Tea':555,'Cran Kaazi':459,'B-52':629}
r20['Beverages']['Classics']={'Bahana Mama':479,'Rum Runner':549,'Purple Haze':5329,'Electric Iced Tea':579,'Cappuccino':129,'Latte':129,'Sapnish Coffee':539,'Mexican Coffee':539,'Irish Coffee':529}
r20['Beverages']['Soft Drinks']={'Red Bull':259,'Sprite':109,'Coke':119,'Fanta':119,'Diet Coke':139,'Coke Zero':149,'Juice':149,'Fresh Lime Soda':109,'Soda':109,'Mineral Water':149}
r20['Starters']={}
r20['Starters']['']={'Tupelo Chicken Tenders':475,'Rockin Wings':530,'Mac and Cheese Poppers':415,'Jumbo Non Veg':745,'Jumbo Veg':600,'Santa Fe Spring Rolls':425}
r20['Burgers']={}
r20['Burgers']['']={'Fiesta Burger':580,'The Big Cheese Burger':605,'Classic Chicken Burger':495,'Hard Rock Veggie Burger':475,'Legendary Chicken Burger':605,'Sri Lankan Veg':475}
r20['Entrees']={}
r20['Entrees']['']={'Grilled Tenderloin Steak':615,'Herb Grilled Chicken':625,'Famous Fajita (Veg)':615,'Famous Fajita (Chicken)':735,'Famous Fajita (Tenderloin)':735,'Penne Arabiata (Veg)':495,'Penne Arabiata (Chicken)':570,'Grilled Jamaican Jerk':615}
r20['Sides']={}
r20['Sides']['Salads']={'Haystack Salad':415,'Chopp Salad':435,'Cobb Salad':495,'Honey Citrus Salad':435,'Caesar Salad':450}
r20['Sides']['Regular']={'French Fries':250,'Cheesy Smashed Potatoes':250,'Twisted Mac Side':285,'Side Original Hard Rock Onion Rings':380,'Garlic Toast':210,'Seasonal Wings':200}
r20['Desserts']={}
r20['Desserts']['']={'Ice Cream':270,'Hot Fudge Sundae':400,'Apple Cobbler':415,'Oreo Cheesecake':615,'Hot Fudge Brownie Sundae':460,'Chocolate Cake':435}
f=open('./RestroBook/static/menu/R.py','w+')
f.truncate(0)
f.write(json.dumps(r20))
f.close()