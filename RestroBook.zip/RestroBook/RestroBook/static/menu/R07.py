import json
r7={}
r7['starter']={}
r7['starter']['Veg']={'Tandoori Grilled Paneer':299,'Steamed and Flamed Mushroom':349,'Charoal Grilled Pineapple':249,'Assorted Grill Veg':299,'Fried Exotic Veg Party':399,'CajuN Spice Potato':210}
r7['starter']['Non Veg']={'Marinated Grilled Prawns':439,'Succulent Lamb Seekh':449,'Salacious Chicken Tikka':399,'Flamed Grilled Basa':399}
r7['starter']['Soup']={'Veg':{'Lemoon Corriander Soup':179,'Sweet Corn':179},'Non Veg':{'Chicken Mushroom':249,'Mutton Broth':299}}
r7['main course']={'Veg':{'Oriental Exoctic Veg':449,'Paneer Tikka in Smoothie Gravy':399,'Dal Tadka':349,'Dal Makhani':349,'Kofta Cury':399},'Non Veg':{'Lucious Chicken Curry':499,'Aromatic Gosht':499,'Chicken Dum Masala':499,'Fish in Chef Signature Sauce':549}}
r7['biryani']={'Veg':{'Plain Rice':199,'Jeera Rice':210,'Veg Handi Biryani':299,'Veg Fried Rice':249},'Non Veg':{'Chicken Biryani':349,'Chicken Fried Rice':349,'Egg Rice':299}}
r7['breads']={'Gilafi Naan':89,'Roti':59,'Laccha Paratha':79,'Varieties of Naan':79,'Missi Roti':99,'Varieties of Stuffed Paratha':119}
r7['sides']={}
r7['sides']['Salads']={'Fruit Salad':219,'Pasta Salad':219,'Green Salad':199,'Sprout Salad':199,'Leafy Salad':199}
r7['sides']['Accompaniements']={'Raita':59,'Curd':59,'Papad':59,'Vinaigrette Veg':69,'Pickle':None}
r7['dessert']={}
r7['dessert']['Indian']={'Halwa':129,'Gulab Jamun':129,'Phirnee':129,'Shahi Tukda':129}
r7['dessert']['continental']={'Regular Pastry':159,'Gooey Brownie':159,'Palatable Mousse':159}
f=open('./RestroBook/static/menu/R.py','w+')
f.truncate(0)
f.write(json.dumps(r7))
f.close()