import json
r6={}
r6['starter']={}
r6['starter']['Soup']={'Kozhi Rasam':229,'Mtton Nenjuelumbu Rasam':249,'Savya Rasa Signature Rasam':99}
r6['starter']['Veg']={'Mundri Badam Unakkal':449,'Siru Sola Varuval':279,'Paneer Monica':299,'Podi Idli Fry':199,'Ulli Vada':229}
r6['starter']['Non Veg']={'Mutta Chutney Kebab':329,'Pallipalayam Kozhi':399,'Kori Ghee Roast':399}
r6['main course']={}
r6['main course']['Veg']={'Kalaan Thirattal':429,'Vellai Kurma':329,'Saiva Veral Kuzhambu':399,'Batata Pathania Gassi':399,'Manga Curry':429}
r6['main course']['Non Veg']={'Tamatar Guddu Pullsu':439,'Yetti Gassi':679,'Kori Gassi':519,'Kori Kundapura':519,'Nalukettu Kozhi Curry':519,'Milagu Kozhi Chettinand':519}
r6['large plates']={}
r6['large plates']['Veg']={'Rameshwaram Pocket Rice':799,'Pottalam Parotta':649,'Mangalore Pottam Rice':699}
r6['large plates']['Non Veg']={'Rameshwaram Pocket Rice':899,'Pottalam Parotta':749,'Mangalore Pottalam Rice':899}
r6['breads']={'Kambu Roti':79,'Bun Parotta':119,'Idiyappa Idly':79,'Neer Dosa':99,'Appam':79,'Muttai Appam':99,'Jolada Roti':79,'Godhumai Roti':79}
r6['biryani']={}
r6['biryani']['Veg']={'Steamed Rice':179,'Kuthari Choru':189,'Thayir Saadham':269,'Saamai Thayir Saadham':299,'Bisi Belle Hulli Anna':329}
r6['biryani']['Non Veg']={'Kozhi Chatti Biryani':669,'Kongu Biryani Chicken/Mutton':(649,749),'Thalassery Biryani':899}
r6['desserts']={'Karupatti Halwa':259,'Flaneer Payasam':259,'Elaneer Pudding':259,'Godhi Huggi':259,'Kavuni Arisi Halwa':259,'Ambalapuzha Payasam':259}
f=open('R.py','w+')
f.truncate(0)
f.write(json.dumps(r6))
f.close()