import json
r2={}
r2['starter']={}
r2['starter']['Hot Dogs']={'Texas Style Chilli Dog':195,'Chicago Bulldog':195}
r2['starter']['Burger']={'Charcoal Black Chicken Burger':195,'Crunchy Chicken Steak Burger':195,'Chilli Cheese Burger':195,'California Burger':185}
r2['sandwiches']={'Cajun Chicken Sandwich':195,'Mumbaiya Chicken Masala Sandwich':195,'Exotic Veggie Sandwich':185}
r2['fries']={'Non Veg':{'BBQ Chicken Fries':185,'Angry Birds':185,'Chicken Maguc Fries':185},'Veg':{'Schezwan Cheese Fries':165,'Cheese Chipotle Fries':165,'Tandoori Chilli Fries':165}}
r2['rolls']={'Chicken Kathi Roll':195,'Paneer Kathi Roll':185}
r2['continental']={'Wok-Tossed Chilli Prawns':335,'Malai Prawns Risotio':335,'Pan Seared Fish':315,'Exotic Bruschetta':215,'Dal Chawal Aranchini':215}
r2['mexican']={'Fish Mexicano':245,'BBQ Chicken Wings':245,'Fiery Chicken Nachos':215,'Crispy Fish Nachos':195,'Tacos De Verde':195}
r2['pizza']={'Chicken Sausage':325,'Three Idiots':325,'Singh is King':295,'Green Indore':295,'Margherita':275,'Stuffed Chicken Pizza':325}
r2['pasta']={'Non Veg':{'Pasta':{'Penne':325,'Farfalle':325,'Fusilli':325,'Spaghetti':325},'Sauce':{'Tomato':'','Alfredo':'','Creamy Chicken':'','Mutton Bolognese':''}},'Veg':{'Pasta':{'Penne':295,'Farfalle':295,'Fusilli':295,'Spaghetti':295},'Sauce':{'Tomato':'','Alfredo':''}}}
r2['desserts']={'Choco Lava':175,'Blueberry Cheesecake':175,'Strawberry Parfait':175,'Red Velvet Pastry':175,'Apple Scotch':175,'Brownie with Ice Cream':175}
f=open('R.py','w+')
f.truncate(0)
f.write(json.dumps(r2))
f.close()