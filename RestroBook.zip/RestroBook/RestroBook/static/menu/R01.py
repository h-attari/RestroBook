import json
r1={}
r1['starter']={}
r1['starter']['Murgh Tandoor']={'Murgh Tandoori':(190,350),'Chicken Tangdi Kebab':270,'Murgh Seekh Kebab':190,'Murgh Musallam':425,'Chicken Platter Kebab':320}
r1['starter']['Mutton Tandoor']={'Mutton Seekh Kebab':220,'Mutton Barra Kebab':360,'Mutton Tangdi Kebab':130,'Raan Nawabi':1400}
r1['starter']['Fish (Bone Less)']={'Fish Tikka':360,'Fish Fry Crispy':320,'Kasoori Fish Fry':275,'Fish Pakoda':250}
r1['starter']['Chinese']={'Veg':{'Chilli Paneer':250,'Crispy Paneer':250,'Crispy Corn':160,'Veg. Manchurian':220},'Chicken':{'Chilli Chicken':265,'Chicken Manchurian':265,'Chicken Spring Roll':265,'Chicken Lollypop':250,'Chicken Fry':230}}
r1['main course']={}
r1['main course']['Chicken']={'Murgh Mumtaz':280,'Chicken Akbari':290,'Murgh Korma':(180,280),'Chicken Bhuna':(180,280),'Chicken Tikka Masala':310,'Kadai Chicken':280}
r1['main course']['Veg']={'Paneer Butter Masala':250,'Paneer Tikka Masala':270,'Paneer Makhmali Masala':250,'Malai Kofta':270,'Aloo Achari':180}
r1['main course']['Mutton']={'Nawabi Nali Korma':(200,300),'Bhuna Gosht':(200,300),'Mutton Nihari':300,'Mutton Angara':300,'Kadai Mutton':300,'Keema Kaleji':260,'Shorbedar Paye':(220,310)}
r1['sides']={}
r1['sides']['Salads']={'Onion Salad':30,'Green Salad':60,'Peanut Chaat':55}
r1['sides']['Papad']={'Roasted Papad':20,'Fry Papad':25}
r1['roti']={'Tandoori Roti':25,'Roomali Roti':30,'Butter Naan':50,'Chilli Garlic Naan':55,'Tawa Roti':20,'Aloo Kulcha':80,'Paneer Kulcha':120,'Keema Kulcha':170}
r1['rice']={}
r1['rice']['Veg']={'Plain Rice':(80,120),'Jeera Rice':(100,160),'Veg Fried Rice':200,'Veg Hakka Noodles':220,'Schezwan Veg Fried Rice':235}
r1['rice']['Non Veg']={'Chicken Fried Rice':240,'Chicken Hakka Noodles':240,'Crispy Chicken Noodles':240,'Schezwan Chicken Fried Rice':240}
r1['rice']['Biryani']={'Biryani-E-Nafees':(180,280),'Fish Biryani':(200,250),'Chicken Tikka Biryani':(190,290),'Mutter Pulao':(100,180)}
r1['desert']={'Flavours Daluda':160,'Sitafal Cream':100,'Shahi Tukda':150,'Gulab Jamun':100,'Gulab Jamun with Rabdi':100,'Fruit Cream':100,'Fruit Salad':80}
r1['beverages']={'Cold Drink':{'Fanta':20,'Coke':20,'Thumbs Up':20,'Appy':15},'Tea':10,'Hot Coffee':25,'Cold Coffee':60}
f=open('R.py','w+')
f.truncate(0)
f.write(json.dumps(r1))
f.close()