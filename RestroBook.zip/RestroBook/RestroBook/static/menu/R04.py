import json
r4={}
r4['starter']={}
r4['starter']['Chaat']={'Dahi Wada':95,'Bhel':95,'Tikki Chaat':1120,'Sev Poori':100,'Pani Patasha(10 pcs)':85,'Dahi Batata Poori':110}
r4['starter']['Vada Pav']={'Jain Vada Pav':13,'Chinese Vada Pav':22,'Chicken Vada Pav':34}
r4['starter']['Burger']={'Vegetable Burger':70,'Tikki Burger':60}
r4['starter']['Soup']={'Tomato Soup':75,'Veg Manchow Soup':85,'Veg Hot and Sour Soup':85,'Veg Sweet Corn Soup':85}
r4['starter']['Chinese']={'Chilli Paneer':250,'Crispy Paneer':250,'Crispy Corn':160,'Veg. Manchurian':220}
r4['sandwiches']={}
r4['sandwiches']['Corn Sandwich']={'Cheese Corn':80,'Corn Paneer':80,'Corn Pizza':130,'Corn Cheese Paneer':150}
r4['sandwiches']['Kaccha Special']={'Bombay Kaccha':40,'Mayo Kaccha':80,'Kaccha Cheese':70}
r4['sandwiches']['Club Sandwich']={'Tandoori':120,'Mexican':130,'American Club':150,'Pizza Club':190,'Italian Club':220}
r4['south indian']={'Idli Sambhar':55,'Vada Sambhar':60,'Idli Vada Mix':60,'Uttapam':100,'Masala Dosa':100}
r4['indian breads']={'Naan':30,'Butter Naan':40,'Paratha Tawa':30,'Paratha Tandoori':30,'Paratha Pudina':35}
r4['chinese']={'Veg Spring Roll':185,'Crispy Vegetable':135,'Chilli Paneer Dry/Gravy':160,'Veg Manchurian Dry/Gravy':135,'Veg Noodles':135,'Veg Fried Rice':135}
r4['sizzler']={'Vegetable Sizzler':265,'Veg Club Sizzler':310,'Veg Sizzler with Baked Veg':310,'Paneer Tikka Sizzler':310,'Chilli Paneer Sizzler':220,'Chinese Combo Sizzler':280}
r4['pizza']={'Veggie Supreme 6"/8"':(165,185),'Paneer Tikka Pizza 6"/8"':(200,220),'Plain Cheese 6"/8"':(175,205)}
r4['pasta']={'Tomato Paprika':185,'Arrabbiata':185,'Pasta in Mushroom Sauce':210,'Macroni Magic':185,'All and All Pasta':215}
r4['rice']={'Plain Rice':(80,120),'Jeera Rice':(100,160),'Veg Fried Rice':200,'Veg Hakka Noodles':220,'Schezwan Veg Fried Rice':235}
r4['curry']={'Paneer Makhani':250,'Kadai Paneer':250}
r4['beverages']={'Fresh Lime Water':50,'Fresh Lime Soda':70,'Badam Thanda':90,'Fruit Beer':85,'Lassi Sweet/Salted':85,'Lassi Mango':100,'Butter Milk':65,'Fruit Punch':120}
r4['dessert']={'Ice Creams':65,'Pudding':60,'Sizzling Desserts':145} 
f=open('./RestroBook/static/menu/R.py','w+')
f.truncate(0)
f.write(json.dumps(r4))
f.close()