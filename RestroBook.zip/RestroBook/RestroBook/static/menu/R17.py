import json
r17={}
r17['Breakfasr']={'Poha':45,'Bread Butter':45,'Bread Jam':45,'Bread Pakoda':70,'Upma':80,'Puri Sabzi':115,'Boiled Egg':30,'Omlette':55}
r17['Starters']={}
r17['Starters']['Soup']={'Veg Tomato Soup':70,'Veg Sweet Corn Soup':80,'Veg Hot and Sour':95,'Veg Manchow':105,'Chicken Clear Soup':120,'Chicken Hot and Sour':130,'Chicken Manchow Soup':145}
r17['Starters']['Veg']={'Aloochat':105,'Chana Chhaat':105,'Mix Pakoda':95,'Finger Chips':90,'Tandoori Aloo':175,'Tandoori Soya Chaap':175}
r17['Starters']['Non Veg']={'Chicken Tikka':295,'Tandoori Chicken':300,'Murg Malai Tikka':300,'Chicken Tikka Lahsuni':295}
r17['Main Course']={'Matar Paneer':195,'Paneer Masala':195,'Paneer Chatpata':195,'Palak Paneer':195,'Paneer Pasanda':195,'Paneer Punjabi':195,'Paneer Kohlapuri':195}
r17['Main Course']['Dal']={'Dal Fry':140,'Dal Tadka':150,'Dal Palak':150,'Dal Punjabi':160,'Dal Handi':175}
r17['Thali']={'Veg Thali':200,'Veg Shahi Thali':290,'Chinese Thali':200,'Non-Veg Thali':295,'Non-Veg Shahi Thali':390}
r17['Sides']={}
r17['Sides']['Papad']={'Fried Papad':22,'Plain Papad':22,'Fried Masala Papad':38,'Masala Papad':38}
r17['Sides']['Salads']={'Onion Salad':45,'Green Salad':70}
r17['Sides']['Raita']={'Curd':25,'Butter Milk':30,'Sweet Lassi':65,'Veg Raita':60,'Boondi Raita':60}
r17['Roti']={'Tawa Roti':15,'Tandoori Roti':15,'Butter Naan':30,'Laccha Paratha':35,'Garlic Naan':40,'Cheese Garlic Naan':40,'Chilly Garlic Naan':40}
r17['Roti']['Parathas']={'Aloo Paratha':50,'Onion Paratha':50,'Mix Paratha':55,'Paneer Paratha':65,'Gobhi Paratha':50}
r17['Roti']['Kulcha']={'Aloo Kulcha':55,'Onion Kulcha':55,'Mix Kulcha':60}
r17['Rice']={'Steamed Rice':80,'Jeera Rice':95,'Butter Khichadi':95,'Tomato Rice':95,'Masala Rice':105,'Masala Khichadi':105}
r17['Desserts']={'Gulab Jamun':50,'Ice Cream':70,'Gulab Jamun with Ice Cream':90}
r17['Shakes']={'Banana Shake':65,'Mango Shake':80,'Chocolate Shake':80,'Banana Basil':90,'Chocolate Oatmeal Shake':105,'Mocha Protein Shake':130}
f=open('./RestroBook/static/menu/R.py','w+')
f.truncate(0)
f.write(json.dumps(r17))
f.close()