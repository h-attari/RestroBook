import json
r13={}
r13['starter']={}
r13['starter']['']={'Doodhiya Kebab':165,'Khasta Mirchi':245,'Veg Shikampuri Kebab':245,'Sev Tikki':265,'Soya Boti':265,'Bhatti Paneer':235}
r13['starter']['Soup']={'Cream of Tomato':165,'Minestrone Soup':165,'Fresh Coconut Soup':165,'Sweet Corn Broth':145}
r13['starter']['Jain']={'Kele ki TikkiKebab':265,'Tulsi Malai Tikka':335,'Chutney Paneer Roll':335}
r13['starter']['Chinese']={'Mustard Paneer':335,'Dil Seasme Chilli Paneer':335,'Charcoaled Momos':265,'Rock Corn':265,'Stuffed Mushroom':335,'Baby Corn with Cashew Nut':265,'American Chop Suey':295,'Veg Thai Rolls':285}
r13['pasta']={}
r13['pasta']['']={'Jalapeno Mac and Cheese':295,'Spaghetti':295,'Aglio e Olio':295}
r13['pizza']={}
r13['pizza']['']={'Margeritta':295,'Calabrese Verfe':365,'Classic Cheese Calzone':365,'Paneer Tikka Pizza':365,'Pesto Pizza':365,'Smoked Veg Pizza':365}
r13['continental']={}
r13['continental']['']={'Potato al Forno Con Formaggio':265,'Veg High Steak':265,'Chargrilled Veg Plateer':295,'Veg au Gratin':335}
r13['main course']={}
r13['main course']['']={'Paneer Loung-Latta':395,'Paneer Lazzat':365,'Paneer aur Methi ki Bhurjee':365,'Khade Masale ka Paneer':365,'Kaju Makhana Makhani':395,'Aloo Bukhara':395,'Subz Kofta':295,'Gulat Aloo':295,'Sev Tamatar':295,'Subz Khurchaan':335,'Tawa Maharaja':495}
r13['main course']['Jain']={'Khadi Hari Subji':295,'Chargrilled Bhutte ka Bharta':295,'Badam Subz Korma':365,'Makhmali Kofta':365,'Paneer Methi Malai':365}
r13['main course']['Dal']={'Dum ki Monk Dal':265,'Tadka Tuka Indori':255,'Bhatti Makhani':335,'Dal Moradabadi':265,'Dal Satvik':265}
r13['breads']={}
r13['breads']['']={'Tandoori Roti':35,'Tawa Roti':35,'Missi Roti':45,'Naan':95,'Lacha Paratha':65,'Kulcha':95}
r13['rice']={}
r13['rice']['']={'Steamed Rice':165,'Jeera Rice':165,'Mutter Pulao':195,'Sun-Dried Fruits Pulao':295,'Bamboo Biryani':365,'Handi Biryani':365}
r13['sides']={}
r13['sides']['Salad']={'Onion Salad':45,'Green Salad':45,'Caesar Salad':235,'Bean Sprout Salad':95}
r13['sides']['Acompaniments']={'Raita Boondi/Pineapple':135,'Mixed Veg Raita':135,'Roasted Cumin and Garlic Raita':135}
r13['sides']['Munchies']={'Roasted/Masala Papad':45,'Smoked Roasted Peas':95,'Peanut Chaat':95,'Corn Chaat':95,'French Fries':165,'Baked Nachos':195,'Mozzerella Sticks':165}
r13['desserts']={}
r13['desserts']['']={'Dried Fruits, Nuts and Cream':245,'Waffle Brownie Sizzler':265,'Fruit Fantasia Waffle':265,'Choco Rocky Road':135,'Rasmalai Pastry':95}
f=open('./RestroBook/static/menu/R.py','w+')
f.truncate(0)
f.write(json.dumps(r13))
f.close()