d=dict()
print(d)
