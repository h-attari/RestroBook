import json
r5={}
r5['starter']={}
r5['starter']['Soup']={'Roasted Tomato Basil':299,'Cream of Mushroom Soup':200,'Lemon Coriander Soup Veg/Non Veg':295,'Cream of Broccoli Soup':225}
r5['starter']['Global']={'Cheese Corn Cigar Roll':299,'Crispy Honey Chilli Potato':265,'Chiili Paneer':265,'Chilli Chicken':295,'Crispy Corn Fried Chicken with Dips':425}
r5['sandwich']={}
r5['sandwich']['']={'Clubhouse Sandwich':295,'Grilled Cheese Sandwich':295}
r5['pasta']={}
r5['pasta']['']={'Agli-o-lio':360,'Penne Arrabiata':360,'Spaghetti Pesto':285}
r5['pizza']={}
r5['pizza']['']={'Chicken Tikka Pizza':475,'Paneer Tikka Pizza':375,'BBQ Pizza':455,'Farmhouse Pizza':425,'Quattro Fomaggi':455}
r5['barbeque']={}
r5['barbeque']['']={'Hara Bhara Kebab':285,'Beet Root Kebab':355,'Paneer Tikka':285,'Tandoori Aloo':275,'Chicken Tikka':345,'Chicken Malai Tikka':345,'Mutton Kakori Kebab':445,'Tandoori Chicken':495}
r5['main course']={}
r5['main course']['Veg']={'Sauted Vegetable':325,'Dahi Baigan':299,'Veg Kofta Curry':325,'Veg Corma':375,'Papad Sabji':275,'Okra':275,'Dal Tadka':250,'Dal Makhani':275,'Chole Masala':285,'Malai Kofta':345,'Palak Corn/Paneer':320,'Mix Vegetable':345}
r5['main course']['Non Veg']={'Mutton Soyta':475,'Chicken Korma':450,'Mutton Neelgiri':490,'Mutton Korma':490,'Degchi ke Sule':495}
r5['sides']={}
r5['sides']['Salad']={'Onion Cucumber Salad':150,'Casear Salad':385,'Greek Salad':385,'Fruit Herb Salad':345}
r5['rice']={}
r5['rice']['']={'Steam Rice':155,'Peas Pulao':199,'Vegetable Rice':180,'Veg Biryani':299,'Chicken Biryani':385,'Mutton Biryani':480}
r5['bread']={}
r5['bread']['']={'Garlic Naan':45,'Butter Naan':40,'Paratha Tawa':45,'Paratha Tandoori':50,'Cheese Naan':115,'Missi Roti':45,'Keema Naan':125}
r5['desserts']={}
r5['desserts']['']={'Rasmalai':149,'Gulab Jamun':149,'Ice Cream':99,'Kulfi':149,'Apple Crumble':165}
f=open('./RestroBook/static/menu/R.py','w+')
f.truncate(0)
f.write(json.dumps(r5))
f.close()