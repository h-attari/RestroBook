import json
r14={}
r14['starter']={}
r14['starter']['Soup']={'Tomato Soup':100,'Veg Manchow Soup':100,'Veg Hot and Sour Soup':100,'Veg Sweet Corn Soup':100}
r14['starter']['Indian']={'Finger Chips':80,'Peanut Chat':90,'Paneer Pakoda':130,'Hara Bhara Kebab':140,'Crunchy Veg':170,'Chilli Paneer':180,'Paneer Makhmali':180,'Veg Crispy':170,'Veg Pakoda':120}
r14['starter']['Chinese']={'Veg Lollipop 3pcs/6pcs':(80,120),'Chinese Bhel':110,'Crispy Corn':140,'Veg/Hakka Noodles':140,'Veg Manchurian':160,'Veg Kothe':170}
r14['main course']={}
r14['main course']['Paneer Taza']={'Mutter Paneer':155,'Palak Paneer':155,'Paneer Korma':160,'Paneer Do Pyaaza':160,'Paneer Bhurji':175,'Kadai Paneer':175,'Butter Paneer Masala':175,'Paneer 65':175,'Paneer Malwa':185}
r14['main course']['Kaju Paneer']={'Kaju Curry':165,'Kaju Paneer':175,'Kaju Kandhari':175,'Kaju Singapori':175,'Kaju Milan':175}
r14['main course']['Kofta']={'Veg Kofta':145,'Navratana Kofta':145,'Palak Kofta':145,'Nargisi Kofta':145,'Malai Kofta':155,'Masala Kofta':155,'Punjabi Kofta':155}
r14['main course']['Green Vegetables']={'Palak':130,'Aloo Palak':130,'Aloo Gobhi':130,'Aloo Methi':130,'Aloo Chole':130,'Bhindi Masala':130,'Chana Masala':130,'Sev Masala':135,'Shahi Palak':145,'Mix Veg':145}
r14['main course']['Dal']={'Dal Fry':125,'Dal Tadka':135,'Dal Makhani':135,'Dal Maharani':135}
r14['rice']={'Plain Rice Half/Full':(70,95),'Jeera Rice Half/Full':(75,105),'Butter Khichadi Half/Full':(75,115),'Veg Pulao':115,'Mutter Pulao':115,'Punjabi Khichadi':170,'Masala Rice':110}
r14['roti']={'Tandoori Roti':11,'Missi Roti':30,'Butter Paratha':30,'Plain Naan':30,'Butter Naan':35,'Butter Kulcha':35,'Stuff Kulcha':40,'Stuff Paratha':40,'Stuff Naan':55,'Garlic Naan':55}
r14['sides']={}
r14['sides']['Salad']={'Onion Salad':25,'Green Salad':40,'Special Salad':45,'Punjabi Salad':55}
r14['sides']['Papad']={'Papad Fry':30,'Papad Roasted':25,'Masala Papad Fry':35,'Masala Papad Roasted':30}
r14['sides']['Dahi']={'Curd Half/Full':(30,55),'Veg Raita':85,'Boondi Raita':90,'Pineapple Raita':95,'Fruit Raita':95}
r14['beverages']={'Lassi':40,'Butter Milk':25,'Cold Drink':20,'Lime Soda':40,'Jal Jeera':25}
r14['desserts']={'Gulab Jmaun':60,'Aamras':90,'Rasmalai':90,'Custard':90,'Shrikhand':90,'Rabdi':90}
r14['desserts']={'Rasmalai':49,'Gulab Jamun':49,'Ice Cream':50,'Kulfi':25,'Rasgulla':40}
f=open('./RestroBook/static/menu/R.py','w+')
f.truncate(0)
f.write(json.dumps(r14))
f.close()