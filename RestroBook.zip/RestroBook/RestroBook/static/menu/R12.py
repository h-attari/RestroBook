import json
r12={}
r12['starter']={}
r12['starter']['']={'Red Thai Curry Paneer Tikka':197,'Spring Roll':157,'Crispy Corn':167,'Bhuna-e-Paneer':187,'Chilli Paneer':167,'Mushroom Pierogi':197}
r12['starter']['Soup']={'Cream of Tomato':97,'Hot and Sour Soup':117,'Tomato Shorba':97,'Sweet Corn Soup':97,'American Manchow Soup':127,'Onion Soup with Cheese Stick':137}
r12['starter']['Dips']={'Fries and Triple-Dips':97,'Peri-Peri Fries and Triple-Dips':117,'Mexican Cheese Nachos with Salsa Dip':157}
r12['starter']['Kebab']={'Veg Seekh Kebab':147,'Hara Bhara Kebab':147,'Corn Kebab':147,'Kebab-e-Kele':187}
r12['starter']['Italian']={'Spaghetti in Arabian Sauce':187,'Penne with Mushroom in Alfredo Sauce':187,'Margeritta Pizza':197,'Roasted Garlic Spinach White Pizza':257}
r12['starter']['Burger']={'Mexican Burger':127,'The Monroe Burger':147}
r12['starter']['Chinese']={'Potato Chilli':97,'Veg Kothe':177,'Noodles':187,'Chowmine with Crispy Tossed Noodles':197}
r12['starter']['Jain']={'Jain Kebab-e-Kele':227,'Jain Paneer Kulcha Shots':177,'Jain Crispy Corn':187,'Jain Chinese Tikki':197}
r12['sandwich']={}
r12['sandwich']['']={'Bombay Masala':97,'Veg Cheese Sandwich':107,'Mushroom and Spinach':147,'Cheesy and Minty Jalapeno':157,'Four Cheese Quattro Formaggio':167}
r12['main course']={}
r12['main course']['']={'Subz-e-Hand':197,'Veg Kothapuri':197,'Corn Kofta':227,'Sunhera Kofta':227,'Mixed Veg Kofta':197,'Dum Aloo':197,'Kaju Curry':257,'Paneer-e-Hand':237,'Shahi Paneer':247,'Butter Paneer Masala':247,'Paneer-e-Punjab':257}
r12['main course']['Dal']={'Da Tadka':117,'Dal Fry':117,'Dal Makhani':147}
r12['main course']['Jain']={'Jain Dal Tadka':127,'Jain Subz-e-Hand':197,'Jain Kaju Curry':257,'Jain Corn Kofta':227}
r12['sizzler']={}
r12['sizzler']['']={'Paneer Cheese-Stick Sizzler':297,'Singaporie Sizzler':297}
r12['rice']={}
r12['rice']['']={'Steamed Rice':117,'Jeera Rice':147,'Mutter Pulao':137,'Subz-e-Hand Biryani':227}
r12['breads']={}
r12['breads']['']={'Tandoori Roti':17,'Missi Roti':37,'Khasta Roti':37,'Cheese Chilli Garlic Naan':57,'Garlic Naan':37,'Cheese Naan':47,'Garlic Naan':37,'Lacha Paratha':37,'Stuffed Paratha':67}
r12['sides']={}
r12['sides']['Salad']={'Onion Salad':37,'Green Salad':67,'Chaat Preparations':97,'Balsamic Watermelon and Feta Cheese Salad':147}
r12['sides']['Acompaniments']={'Raita Boondi/Pineapple/Veg':87,'Papad Roasted/Fried':17,'Masala Papad':37}
r12['dessert']={}
r12['dessert']['']={'Double Ice Cream Scoops':67,'Chocolate Quattro-Waffles with Ice Cream':167,'Caramalised Apple and Ice Cream':157,'Tiramisu':197}
f=open('./RestroBook/static/menu/R.py','w+')
f.truncate(0)
f.write(json.dumps(r12))
f.close()