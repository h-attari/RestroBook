import json
r15={}
r15['starter']={'Peanut Chaat':60,'Veg Cutlet':80,'Mix Pakoda':80,'Hara Bhara Kebab':90,'Dahi Kebab':90,'Paneer Pakoda':100,'Crispy Corn':100,'Veg Kothe':110,'French Fries':80,'Peri Peri French Fries':90,'Smilies':80,'Veggie Nuggets':80}
r15['starter']['Soup']={'Tomato Soup':80,'Veg Manchow Soup':80,'Veg Hot and Sour Soup':80,'Veg Sweet Corn Soup':85,'Lemon Corriander':80}
r15['starter']['Chinese']={'Veg Chowmein':80,'Veg Noodles':80,'Hakka Noodle':100,'Veg Manchurian':90,'Manchurian with Noodles':100,'Manchurian with Rice':110,'Chilli Paneer':110,'Paneer Crispy':120,'Paneer 65':120,'Veg Spring Roll':130,'Paneer Roll':150,'Fry Momos':80}
r15['starter']['Toast']={'Veg Cheese Toast':60,'Cheese Chilly Garlic Toast':70,'Mushroom Chilly Toast':85}
r15['starter']['Chatpata Chaat']={'Poha':14,'Usal Poha':25,'Dal Kachori':14,'Aloo Kachori':14,'Aloo Pyaz Kachori':20,'Samosa':14,'Chole Kulche':30,'Chole Tikkia':45,'Vada Pav':30,'Baked Patties':20,'Khandvi':28,'Bhel Puri':35,'Katori Chaat':40,'Dahi Vada':45,'Aloo Patties':16}
r15['pizza']={'Cheese Veg Pizza':110,'Onion Capsicum Pizza':110,'Garlic Chilly Pizza':110,'Cheese Pizza':115,'Corn Pizza':115,'Onion Tomato Pizza':115,'Mushroom Pizza':115,'Chinese Pizza':120,'Jain Pizza':120,'Paneer Tikka Pizza':130}
r15['burger']={'Aloo Tikki Burger':70,'Veggie Burger':80}
r15['sandwich']={'Bombay Kachha Sandwich':39,'Veg Cheese Sandwich':70,'Aloo Masala Sandwich':70,'Cheese Chutney Sandwich':75,'Pizza Sandwich':80,'Cheese Corn Sandwich':80,'Mayo Corn Sandwich':80,'Jain Sandwich':80}
r15['rolls']={'Achari Veg Roll':60,'Potato Fenugreek Roll':60,'Chinese Schezwan Roll':70,'Cheese Chutney Roll':80}
r15['maggie']={'Plain Maggie':50,'Masala Maggie':55,'Veg Maggie':60,'Corn Maggie':60,'Cheese Maggie':65,'Veg Cheese Maggie':70}
r15['south indian']={'Plain Dosa':70,'Masala Dosa':80,'Mysore Plain Dosa':75,'Mysore Masala Dosa':90,'Paneer Plain Dosa':90,'Paneer Plain Dosa':110,'Cheese Plain Dosa':100,'Cheese Masala Dosa':120,'Spring Masala Dosa':110,'Rava Plain Dosa':100,'Rava Masala Dosa':110,'Onion Rava Plain Dosa':100,'Onion Rava Masala Dosa':110}
r15['north indian']={'Chole Tikkia':45,'Chole Kulche':50,'Plain Tikka':25,'Chole Bhature':100,'Paneer Chole Bhature':120,'Cheese Chole Bhature':130}
r15['pav bhaji']={'Pav Bhaji':80,'Masala Pav Bhaji':85,'Jain Pav Bhaji':90,'Paneer Pav Bhaji':100,'Cheese Pav Bhaji':100}
r15['main course']={}
r15['main course']['Dal']={'Dal Fry':90,'Dal Jeera':95,'Dal Tadka':100,'Dal Makhani':120,'Hari Mirchi Pyaaz Fry Dal':100}
r15['main course']['Sabzi']={'Shahi Paneer':135,'Kadhai Paneer':135,'Handi Paneer':135,'Mutter Paneer':125,'Paneer Koffta':135,'Palak Paneer':125,'Mushroom Paneer':150,'Paneer Do Pyaaza':125,'Kaju Paneer':150,'Chola Paneer':140,'Kaju Paneer':140,'Sev Tamatar':90,'Chana Masala':90}
r15['roti']={'Tawa Roti':12,'Tawa Paratha':18,'Tandoori Roti':15,'Butter Tandoori Roti':18,'Mix Roll':50,'Makka Roll':60,'Butter Naan':50,'Garlic Naan':55,'Cheese Naan':55,'Chilli Naan':55,'Chinese Naan':60,'Garlic Chilli Naan':70}
r15['sides']={}
r15['sides']['Papad']={'Papad Roasted':15,'Papad Fry':20,'Papad Masala Roasted':25,'Papad Masala Fry':25}
r15['sides']['Salad']={'Onion Salad':30,'Green Salad':40,'Kachumar Salad':40,'Fruit Salad':60,'Peanut Salad':60}
r15['sides']['Raita']={'Plain Curd':30,'Sweet Curd':40,'Boondi Raita':40,'Veg Raita':50,'Fruit Raita':50}
f=open('R.py','w+')
f.truncate(0)
f.write(json.dumps(r15))
f.close()