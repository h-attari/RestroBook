function restmodal(key,value,abt,menu)
{
	modal = document.getElementById("book-modal");
	modal.querySelector(".modal-title").innerHTML=value;
	modal.querySelector("#restdata").value = key;
	modal.querySelector("#abt").innerHTML = abt;
	modal.querySelector("#menubtn").value = menu;
}

function restmenu()
{
	menu = document.getElementById("menubtn").value;
	menu = JSON.parse(menu);
}

function restinfo(rid,rname,rmob,rmail,radd,rcity,rcntry)
{
	modal = document.getElementById("rest-modal");
	modal.querySelector("#rid").innerHTML = rid;
	modal.querySelector("#rname").innerHTML = rname;
	modal.querySelector("#rmob").innerHTML = rmob;
	modal.querySelector("#rmail").innerHTML = rmail;
	modal.querySelector("#radd").innerHTML = radd + ', ' + rcity + ', ' + rcntry;
}

function uinfo(uid,uname,umob,umail)
{
	modal = document.getElementById("user-modal");
	modal.querySelector("#uid").innerHTML = uid;
	modal.querySelector("#uname").innerHTML = uname;
	modal.querySelector("#umob").innerHTML = umob;
	modal.querySelector("#umail").innerHTML = umail;
}

function check(firstname,lastname,mobile,email)
{
	chkbx = document.getElementById("datacheckbox");
	first = document.getElementById("firstname");
	last = document.getElementById("lastname");
	mob = document.getElementById("mobnum");
	eml = document.getElementById("emailid");
	if(chkbx.checked)
	{
		first.value = firstname;
		first.disabled = true;
		last.value = lastname;
		last.disabled = true;
		mob.value = mobile;
		mob.disabled = true;
		eml.value = email;
		eml.disabled = true;
	}
	else
	{
		first.value = null;
		first.disabled = false;
		last.value = null;
		last.disabled = false;
		mob.value = null;
		mob.disabled = false;
		eml.value = null;
		eml.disabled = false;
	}
}

function mobile(n)
{
	var flag=true;
	var a=/^[0-9]+$/;
	mob=document.getElementById(n).value;
	if(mob.length==0||a.test(mob))
	{
		if(mob.length==10||mob.length==0)
		{
			document.getElementById("error").innerHTML=null;
		}
		else
		{
			document.getElementById("error").innerHTML="Invalid Mobile no.";
			document.getElementById(n).value=null;
			flag=false;
		}
	}
	else
	{
		document.getElementById("error").innerHTML="Invalid Mobile no.";
		document.getElementById(n).value=null;
		flag=false;
	}
	return flag;
}

function mail(n,error)
{
	var flag=true;
	var a=/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
	mail=document.getElementById(n).value;
	if(a.test(mail)||mail.length==0)
	{
		document.getElementById(error).innerHTML=null;
	}
	else
	{
		document.getElementById(error).innerHTML="Invalid Email";
		document.getElementById(n).value=null;
		flag=false;
	}
	return flag;
}

function erclr(error)
{
	document.getElementById(error).innerHTML = null;
}