function restmodal(key,value,abt)
{
	modal = document.getElementById("book-modal");
	modal.querySelector(".modal-title").innerHTML=value;
	modal.querySelector("#restdata").value = key;
	modal.querySelector("#abt").innerHTML = abt;
}

function restinfo(rid,rname,rmob,rmail,radd,rcity,rcntry)
{
	modal = document.getElementById("rest-modal");
	modal.querySelector("#rid").innerHTML = rid;
	modal.querySelector("#rname").innerHTML = rname;
	modal.querySelector("#rmob").innerHTML = rmob;
	modal.querySelector("#rmail").innerHTML = rmail;
	modal.querySelector("#radd").innerHTML = radd + ', ' + rcity + ', ' + rcntry;
}

function uinfo(uid,uname,umob,umail)
{
	modal = document.getElementById("user-modal");
	modal.querySelector("#uid").innerHTML = uid;
	modal.querySelector("#uname").innerHTML = uname;
	modal.querySelector("#umob").innerHTML = umob;
	modal.querySelector("#umail").innerHTML = umail;
}