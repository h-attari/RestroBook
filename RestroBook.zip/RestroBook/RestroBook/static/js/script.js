function restmodal(key,value,abt)
{
	modal = document.getElementById("book-modal");
	modal.querySelector(".modal-title").innerHTML=value;
	modal.querySelector("#restdata").value = key;
	modal.querySelector("#abt").innerHTML = abt;
}