from django.shortcuts import render, redirect
import mysql.connector as mysql
from random import randint

def locations():
	conn = mysql.connect(host="localhost",user="root",password="root",database="RestroBook")
	cr = conn.cursor()
	countries = []
	qu = "select country_name from Country"
	cr.execute(qu)
	temp = cr.fetchall()
	for x in temp:
		countries.append(x[0])
	return countries

def index(req):
	countries =  locations()
	return render(req,'index.html', {"Location":countries})

def logintask(req):
	conn = mysql.connect(host="localhost",user="root",password="root",database="RestroBook")
	cr = conn.cursor()
	login_id = req.POST.get("lmail")
	pswrd = req.POST.get("pswd")
	if str(login_id).isnumeric():
		qu = "select pswrd from Users where mobile = %s"
	else:
		qu = "select pswrd from Users where email = %s"
	v = (login_id,)
	cr.execute(qu,v)
	check = cr.fetchone()
	check = check[0][:len(check[0])-10]
	return render(req, 'index.html')

def signtask(req):
	conn = mysql.connect(host="localhost",user="root",password="root",database="RestroBook")
	cr = conn.cursor()
	fname = req.POST.get("fname")
	lname = req.POST.get("lname")
	mob = req.POST.get("mob")
	email = req.POST.get("smail")
	user_id = fname[:2] + lname[:2] + mob[:3] + str(randint(100,999))
	pswrd = req.POST.get("pswrd") + user_id
	qu = "insert into users(user_id, first_name, last_name, mobile, email, pswrd) values('{0}','{1}','{2}','{3}','{4}','{5}')".format(user_id,fname,lname,mob,email,pswrd)
	cr.execute(qu)
	conn.commit()
	conn.close()
	return redirect("/")