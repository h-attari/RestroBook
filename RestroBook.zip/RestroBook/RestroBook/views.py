from django.shortcuts import render, redirect
import mysql.connector as mysql

def locations():
	conn = mysql.connect(host="localhost",user="root",password="root",database="RestroBook")
	cr = conn.cursor()
	countries = []
	qu = "select country_name from Country"
	cr.execute(qu)
	temp = cr.fetchall()
	print(temp)

def index(req):
	locations()
	return render(req,'index.html')