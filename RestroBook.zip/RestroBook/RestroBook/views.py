from django.shortcuts import render, redirect
import mysql.connector as mysql
from random import randint
import smtplib
from email.mime.text import MIMEText
import user.views as Uviews

def locations():
	conn = mysql.connect(host="localhost",user="root",password="root",database="RestroBook")
	cr = conn.cursor()
	countries = []
	cities = {}
	qu = "select country_name from Country"
	cr.execute(qu)
	temp = cr.fetchall()
	for x in temp:
		countries.append(x[0])
	for x in countries:
		temp = []
		qu = "select city_name from city where country=(select country from country where country_name=%s)"
		v = (x,)
		cr.execute(qu,v)
		rec = cr.fetchall()
		for y in rec:
			temp.append(y[0])
		cities[x] = temp
	conn.close()
	return cities

def index(req):
	loc =  locations()
	user = []
	if req.session.has_key('id'):
		user.append(req.session['id'])
		user.append(req.session['name'])
	return render(req,'index.html', {"Location":loc, "user":user})

def logintask(req, cred = []):
	conn = mysql.connect(host="localhost",user="root",password="root",database="RestroBook")
	cr = conn.cursor()
	if cred == []:
		login_id = req.POST.get("lmail")
		pswrd = req.POST.get("pswd")
	else:
		login_id = cred[0]
		pswrd = cred[1]
	if str(login_id).isnumeric():
		qu = "select user_id, first_name, last_name, pswrd from Users where mobile = %s"
	else:
		qu = "select user_id, first_name, last_name, pswrd from Users where email = %s"
	v = (login_id,)
	cr.execute(qu,v)
	check = cr.fetchone()
	if check != None and check[3][:-10] == pswrd:
		req.session['id'] = check[0]
		req.session['name'] = check[1].capitalize() + ' ' + check[2].capitalize()
		check = check[3][:len(check[3])-10]
	else:
		qu = "select admin_id, first_name, last_name from admin where admin_id=%s and pswrd=%s"
		v = (login_id,pswrd)
		cr.execute(qu,v)
		rec = cr.fetchone()
		if rec != None:
			req.session['id'] = rec[0]
			req.session['name'] = rec[1].capitalize() + ' ' + rec[2].capitalize()
			conn.close()
			return redirect('/admins/login')
		else:
			qu = "select rest_id,rest_name from restaurants where rest_id=%s and pswrd=%s"
			v = (login_id,pswrd)
			cr.execute(qu,v)
			rec = cr.fetchone()
			if rec != None:
				req.session['id'] = rec[0]
				req.session['name'] = rec[1]
				conn.close()
				return redirect('/restaurant/login')
	conn.close()
	return redirect('/')

def signtask(req, cred = []):
	conn = mysql.connect(host="localhost",user="root",password="root",database="RestroBook")
	cr = conn.cursor()
	if cred == []:
		fname = req.POST.get("fname")
		lname = req.POST.get("lname")
		mob = req.POST.get("mob")
		email = req.POST.get("smail")
		pswrd = req.POST.get("pswrd")
	else:
		fname = cred[0]
		lname = cred[1]
		mob = cred[2]
		email = cred[3]
		pswrd = cred[4]
	user_id = fname[:2] + mob[:3] + lname[:2] + str(randint(100,999))
	pswrd += user_id
	qu = "insert into users(user_id, first_name, last_name, mobile, email, pswrd) values('{0}','{1}','{2}','{3}','{4}','{5}')".format(user_id,fname,lname,mob,email,pswrd)
	cr.execute(qu)
	conn.commit()
	conn.close()
	return redirect("/")

def forgot(req, mail=''):
	conn = mysql.connect(host="localhost",user="root",password="root",database="RestroBook")
	cr = conn.cursor()
	if mail == '':
		mail = req.POST.get("forgotmail")
	qu = "select user_id, first_name, last_name, pswrd from users where email=%s"
	v = (mail,)
	cr.execute(qu,v)
	rec = cr.fetchone()
	if rec != None:
		pswrd = rec[3][:len(rec[3])-10]
		server = smtplib.SMTP('smtp.gmail.com', 587)
		html="""
		<html>
			<body>
				<div>
					<p style="font-size:18px;">
						Welcome <i>{0} {1} </i>!
					</p>
					<br><br>
					<p style="font-size:16px;">
						The password for your RestroBook account <b><i>{2}</i></b> is: <b>{3}</b>
					</p>
				</div>
			</body>
		</html>""".format(rec[1],rec[2],rec[0],pswrd)
		msg=MIMEText(html, 'html')
		server.starttls()
		server.login("hlucifer44@gmail.com", "1060543987")
		server.sendmail("hlucifer44@gmail.com", mail, msg.as_string())
		server.quit()
	conn.close()
	return redirect('/')

def logout(req):
	try:
		del req.session['id']
		del req.session['name']
	except:
		pass
	req.session.flush()
	return redirect('/')